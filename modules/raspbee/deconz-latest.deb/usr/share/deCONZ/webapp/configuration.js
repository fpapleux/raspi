var config;
var POLL_DELAY = 5000;

var app = app || {};

app.updateNotification = $("#update-notification");

// Set the name of the hidden property and the change event for visibility
var hidden, visibilityChange; 
if (typeof document.hidden !== "undefined") { // Opera 12.10 and Firefox 18 and later support 
  hidden = "hidden";
  visibilityChange = "visibilitychange";
} else if (typeof document.mozHidden !== "undefined") {
  hidden = "mozHidden";
  visibilityChange = "mozvisibilitychange";
} else if (typeof document.msHidden !== "undefined") {
  hidden = "msHidden";
  visibilityChange = "msvisibilitychange";
} else if (typeof document.webkitHidden !== "undefined") {
  hidden = "webkitHidden";
  visibilityChange = "webkitvisibilitychange";
}

/**
 * Displays or hides the network is open warning.
 */
function checkNetworkOpenWarning() {
    if ($.trim($('#network-open-alert').html()).length) {
        // case 1 remove warning
        if (config.config.permitjoin === 0) {
            $('#network-open-alert').html("");
            return;
        }

        // case 2 warning already visible, do nothing
        return;
    }

    // case 3 display warning
    if (config.config.permitjoin > 0) {
        var txt = '<div class="alert alert-block alert-warning">';
        txt += '<button type="button" class="close" data-dismiss="alert">&times;</button>';
        txt += '<strong>Warning!</strong> The network is <em>open</em>, please close the network after setup in the <a href="edit_network.html">network settings</a>!';
        txt += '</div>';
        $('#network-open-alert').html(txt);
    }
}

/**
 * Displays or hides the otau is busy warning.
 */
function checkOtauBusyWarning() {
    if (config.config.otaustate === "busy") {
        $("#otau-alert").removeClass('hidden');
    }
    else {
        if (!$("#otau-alert").hasClass('hidden')) {
            $("#otau-alert").addClass('hidden');
        }
    }
}

/**
 * Displays or hides the update is available notification.
 */
function checkUpdateNotification() {
    var curVersion = config.config.swversion;
    var updateVersion = config.config.swupdate.version;
    
    if (compareVersionNumbers(curVersion, updateVersion) === -1)
    {
        app.updateNotification.removeClass('hidden');
    }
    else if (config.config.fwneedupdate)
    {
        app.updateNotification.removeClass('hidden');   
    }
    else {
        if (! app.updateNotification.hasClass('hidden')) {
            app.updateNotification.addClass('hidden');
        }
    }
}

/**
 * Updates configuration state.
 */
function checkUpdatedData() {

    if (hidden !== 'undefined') {
        if (document[hidden] === true) {
            console.log('don\'t update while browser window is hidden');
            setTimeout(checkUpdatedData, POLL_DELAY);
            return;
        }
    }

    $.ajax({
        url: 'api/' + apikey,
        dataType: 'json',
        type: 'GET',
        cache: false,
        contentType: 'application/json; charset=utf-8',
        headers: {
            'If-None-Match': config.etag,
            'Accept': apiversion
        },
        success: function(json, status, xhr) {

            if (xhr.status === 304) {
                // call self
                setTimeout(checkUpdatedData, POLL_DELAY);
                return;
            }

            // if the group count changes rebuild ui completely
            // note: since groups is a object noth a array we can't use groups.length here
            if (_.size(config.groups) !== _.size(json.groups)) {
                config = json;
                config.etag = xhr.getResponseHeader("ETag");

                // all new
                groupArr = [];
                $(pageLightList).html("");

                showConfiguration();

                // make available for caching
                if (Modernizr.sessionstorage) {
                    sessionStorage.config = xhr.responseText;
                }
                // call self
                setTimeout(checkUpdatedData, POLL_DELAY);
                return;
            }

            var g;
            var l;
            var txt;
            var changed  = false;

            for (g in json.groups) {
                json.groups[g].id = g;
            }

            for (l in json.lights) {
                json.lights[l].id = l;
            }

            for (g in json.groups) {
                var group = json.groups[g];
                var groupCache = config.groups[g];

                // needed to be equal api that lights use
                group.type = TYPE_GROUP;
                group.hasColor = true;
                group.state = group.action;

                if (groupCache !== undefined) {
                    if ((group.etag != groupCache.etag) || (group.lights.length !== groupCache.lights.length)) {
                        txt = groupToHtml(group, json.lights);
                        $('div.location[data-gid="' + group.id + '"]').replaceWith(txt);
                        changed = true;
                    }
                }
            }

            for (l in json.lights) {
                var light = json.lights[l];
                var lightCache = config.lights[l];

                if (lightCache !== undefined) {
                    if (light.etag != lightCache.etag) {
                        txt = lightToHtml(light);
                        $('tr[data-lid="' + light.id + '"]').replaceWith(txt);
                        changed = true;
                    }
                }
            }

            // always copy permit join
            config.config.permitjoin = json.config.permitjoin;

            // always copy version information
            config.config.fwneedupdate = json.config.fwneedupdate;
            config.config.fwversion = json.config.fwversion;
            config.config.swversion = json.config.swversion;
            config.config.swupdate = json.config.swupdate;

            if (changed) {
                config = json;

                // make available for caching
                if (Modernizr.sessionstorage) {
                    sessionStorage.config = xhr.responseText;
                }

                // update lights
                updateLights();
                recalcAllGroupParams();
                adjustLightNames();
            }

            checkNetworkOpenWarning();
            checkOtauBusyWarning();
            checkUpdateNotification();

            config.etag = xhr.getResponseHeader("ETag");
            if (!config.etag) {
                config.etag = "";
            }

            // call self
            setTimeout(checkUpdatedData, POLL_DELAY);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            if (jqXHR.status == 0 || textStatus == "timeout") {
                showAlert('alert-error', '<b>Error!</b> Lost connection, retry in one second ...');
                // try from beginning on (also to clear the alert box on success)
                setTimeout(getFullConfiguration, 1000);
                return;
            }

            switch (jqXHR.status) {
            case 403:
                window.location.assign("/login.html");
                break;

            default:
                setTimeout(checkUpdatedData, POLL_DELAY);
                break;
            }
        },
        timeout: 10000
    });
}

function showConfiguration() {
    clearAlert(); // all new

    // update lights
    updateLights();

    // update groups
    checkGroups(config.groups);
    recalcAllGroupParams();

    checkNetworkOpenWarning();
    checkOtauBusyWarning();
    checkUpdateNotification();
}

/**
 * Get full configuration state from cache if available.
 * @return {bool} true if loaded from cache
 */
function getFullConfigurationCache() {
    if (Modernizr.sessionstorage) {
        if (sessionStorage.config) {
            config = JSON.parse(sessionStorage.config);
            showConfiguration();
            setTimeout(checkUpdatedData, 500);
            return true;
        }
    }
    return false;
}

/**
 * Initial get full configuration state.
 */
function getFullConfiguration() {

    $.ajax({
        url: 'api/' + apikey,
        dataType: 'json',
        type: 'GET',
        cache: false,
        contentType: 'application/json; charset=utf-8',
        headers: { 'Accept': apiversion },
        success: function(json, status, xhr) {
            config = json;
            config.etag = xhr.getResponseHeader("ETag");

            showConfiguration();

            // make available for caching
            if (Modernizr.sessionstorage) {
                sessionStorage.config = xhr.responseText;
            }

            setTimeout(checkUpdatedData, 5000);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            switch (jqXHR.status) {
            case 403:
                window.location.assign("/login.html");
                break;

            default:
                setTimeout(getFullConfiguration, 1000);
                showAlert('alert-error', '<b>Error!</b> Lost connection, retry in one second ...');
                break;
            }
        },
        timeout: 10000
    });
}
