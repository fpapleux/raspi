var gid = null;

function displayGroups(config) {

    gid = getURLParameter('group');

    if (gid === null) {
        // go back if no id was specified
        window.location.assign('edit_groups.html');
    }

    var txt = '<div class="span12">';
    var group = undefined;

    for (var id in config.groups) {

        if (id === gid) {
            // found
            group = config.groups[id];
            break;
        }
    }

    if (group === undefined) {
        // go back if no id was specified
        window.location.assign('edit_groups.html');
    }

    txt += '<form>';
    txt += '<table class="table noborder">';
    txt += '<thead>';
    txt += '<th>Name</th><th>Model</th><th>Vendor</th><th>Version</th>';
    txt += '</thead>';
    txt += '<tbody>';

    for (var id in config.lights) {
        var l = config.lights[id];
        var checked = false;
        var disabled = "";
        var muted = "";

        // if already in the group mark checked
        for (var i = 0; i < group.lights.length; i++) {
            if (group.lights[i] == id) {
                checked = true;
                break;
            }
        }

        if (l.state.reachable == false) {
            disabled = " disabled ";
            muted = "muted";
        }

        txt += '<tr>';
        txt += '<td class="' + muted + '">';
        txt += '<label class="checkbox">';
        txt += '<input type="checkbox"' + disabled + ' data-lid="' + id + '"' + (checked ? ' checked="checked"' : '') + '> ' + l.name
        txt += '</label>';
        txt += '</td>';
        txt += '<td class="' + muted + '">' + l.modelid + '</td>';
        txt += '<td class="' + muted + '">' + l.manufacturer + '</td>';
        txt += '<td class="' + muted + '">' + l.swversion + '</td>';
        txt += '</tr>';
    }

    txt += '</tbody>';
    txt += '</table>';
    txt += '</form>';
    txt += '</div>';

    $('.headerGroupName').html(group.name);
    $('.groups').html(txt);
}

function getFullConfiguration() {

    $.ajax({
        url: 'api/' + apikey,
        dataType: 'json',
        type: 'GET',
        cache: false,
        contentType: 'application/json; charset=utf-8',
        headers: { 'Accept': apiversion },
        success: function(json) {
            clearAlert();
            displayGroups(json);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            switch (jqXHR.status) {
            case 403:
                window.location.assign("/login.html");
                break;

            default:
                setTimeout(getFullConfiguration, 1000);
                showAlert('alert-error', '<b>Error!</b> Lost connection, retry in one second ...');
                break;
            }
        },
        timeout: 8000
    });
}

function onSubmit() {

    // only if we have a valid group id
    if (gid === null) {
        return;
    }

    var lights = [];

    $("input[data-lid]").each(function( index ) {
        if (this.checked) {
            lights.push($(this).attr('data-lid'));
        }
    });

    $.ajax({
        url: 'api/' + apikey + '/groups/' + gid,
        dataType: 'json',
        type: 'PUT',
        cache: false,
        contentType: 'application/json; charset=utf-8',
        headers: { 'Accept': apiversion },
        data: "{ \"lights\": " + JSON.stringify(lights) + " }",
        success: function(json) {
            window.location.assign('edit_groups.html');
        },
        error: function(jqXHR, textStatus, errorThrown) {
            showAlert('alert-error', '<b>Error!</b> Failed to set group members.');
        }//,
        //timeout: 2000,
    });
}
