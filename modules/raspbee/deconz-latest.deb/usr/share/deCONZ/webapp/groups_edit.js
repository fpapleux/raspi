var app = app || {};
function displayGroups(config) {

    var odd = false;
    var txtLeft = '<div class="span6">';
    var txtRight = '<div class="span6">';

    for (var id in config.groups) {
        var g = config.groups[id];

        var scenes = 'scenes';
        if (g.scenes.length == 1) {
            scenes = 'scene';
        }

        var txt = '<h4>' + g.name + ' <small>' + g.lights.length + ' lights, ' + g.scenes.length + ' ' + scenes + '</small></h4>';
        txt += '<div class="btn-toolbar">';
        txt += '<a class="btn" href="edit_group_members.html?group=' + id + '">edit members</a>';
        txt += '<a class="btn btn-danger" href="#" onclick="showDeleteGroupModal(' + id + ');return false;">delete</a>';
        txt += '</div>';

        if (odd) {
            txtRight += txt;
        }
        else {
            txtLeft += txt;
        }
        odd = !odd;
    }

    txtLeft += '</div>';
    txtRight += '</div>';

    $('.groups').html(txtLeft + txtRight);
    app.config = config;
}

// get full configuration 
function getFullConfiguration() {

    $.ajax({
        url: 'api/' + apikey,
        dataType: 'json',
        type: 'GET',
        cache: false,
        contentType: 'application/json; charset=utf-8',
        headers: { 'Accept': apiversion },
        //processData: false,
        success: function(json, status, xhr) {
            // make available for caching
            sessionStorage.config = xhr.responseText;
            clearAlert();
            displayGroups(json);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            switch (jqXHR.status) {
            case 403:
                window.location.assign("/login.html");
                break;

            default:
                setTimeout(getFullConfiguration, 1000);
                showAlert('alert-error', '<b>Error!</b> Lost connection, retry in one second ...');
                break;
            }
        },
        timeout: 8000
    });

}

function createGroup(name) {

    var out = { "name": name };

    $.ajax({
        url: 'api/' + apikey + '/groups',
        dataType: 'json',
        type: 'POST',
        cache: false,
        contentType: 'application/json; charset=utf-8',
        headers: { 'Accept': apiversion },
        //processData: false,
        data: JSON.stringify(out),
        success: function(json) {
            // force reload 
            sessionStorage.removeItem("config");
            location.reload(true);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log("textStatus:", textStatus + ' ' + errorThrown);
            console.log(jqXHR.responseText);
            //setTimeout(updateLights, 15000);
        }//,
        //timeout: 2000,
    });

}

function showDeleteGroupModal(id) {
    var name = "";

    if (app.config.groups) {
        var g = app.config.groups[id];
        name = g.name
    }

    $('#btnDeleteGroup').data('id', id);
    $('#deleteGroupModalLabel').html('Delete group ' + name + '?');
    $('#deleteGroupModal').modal('show');
}

function deleteGroup(id) {
    $.ajax({
        url: 'api/' + apikey + '/groups/' + id,
        dataType: 'json',
        type: 'DELETE',
        cache: false,
        headers: { 'Accept': apiversion },
        //contentType: 'application/json; charset=utf-8',
        //processData: false,
        success: function(json) {
            // force reload 
            sessionStorage.removeItem("config");
            location.reload(true);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log("textStatus:", textStatus + ' ' + errorThrown);
            console.log(jqXHR.responseText);
            //setTimeout(updateLights, 15000);
        }//,
        //timeout: 2000,
    });

}
