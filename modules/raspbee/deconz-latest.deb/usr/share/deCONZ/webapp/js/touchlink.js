var app = app || {};

var Touchlink = (function () {
	var tl = {};

	return tl;
}());

/**
 * Model which represents a single node in the touchlink list.
 */
app.TouchlinkNode = Backbone.Model.extend({
	defaults: {
		name: 'unknown',
		factoryNew: false
	},
	initialize: function() {
		this.on('change', function() {
			console.log('change event');
		});
	},

	// send identify command to the node
	identify: function() {
		$.post('/api/' + apikey + '/touchlink/' + this.id + '/identify', function(data) {
  			clearAlert();
		})
		.fail(function(jqXHR, textStatus, errorThrown) {
			// temporary busy
			if (jqXHR.status === 503) { // Service Unavailable
				showAlert('alert-warning', '<b>Busy!</b> Please try again in a few seconds.');
			}
		});
	},
	// send reset to factory new command to the node
	resetToFactoryNew: function() {
		$.post('/api/' + apikey + '/touchlink/' + this.id + '/reset', function(data) {
  			showAlert('alert-info', 'OK! Reset to factory new command send.');
		})
		.fail(function(jqXHR, textStatus, errorThrown) {
			// temporary busy
			if (jqXHR.status === 503) { // Service Unavailable
				showAlert('alert-warning', '<b>Busy!</b> Please try again in a few seconds.');
			}
		});
	}
});

/**
 * Callback then scan results are received.
 */
function fetchScanResultSuccess(collection, response, options) {
	// reset and hide progress bar
	$('#scanProgressBar').css('display', 'none');
	$('#scanProgressBar .bar').css('width', '0%');

	if (collection.length === 0) {
		showAlert('alert-warning', '<b>Note!</b> No lights where found. Please try again and make sure the lights are close enough to the gateway.');
	}
	else {
		showAlert('alert-success', '<b>OK!</b> Found ' + collection.length + ((collection.length === 1) ? ' light' : ' lights') + '.');
	}
}

/**
 * Collection for the nodes found by a touchlink scan reqeuest.
 */
var TouchlinkNodeCollection = Backbone.Collection.extend({
	model: app.TouchlinkNode,
	url: function() {
		return '/api/' + apikey + '/touchlink/scan';
	},

	parse: function(response, options) {
    	// prepare scan results to show
		var arr = [];
		_.each(response.result, function(item, index) {
			var node = {
				id: index,
				factoryNew: item.factoryNew,
				name: item.name || 'Light ' + index,
				address: item.address,
                rssi: item.rssi,
                channel: item.channel,
                panid: item.panid
			};
			arr.push(node);
		});
		return arr;
	}
});

/**
 * View for a single touchlink node.
 */
app.TouchlinkNodeView = Backbone.View.extend({
	tagName: 'tr',

	// cache the template function for a single view
	template: _.template($('#tl-item-template').html()),

	initialize: function() {
		this.listenTo(this.model, 'change', this.render);
	},

	// DOM events specific to an item
	events: {
		'click .identify': 'identify',
		'click .reset': 'resetToFactoryNew'
	},

	render: function() {
		this.$el.html(this.template(this.model.toJSON()));
		this.$identify = this.$('.identify');
		this.$reset = this.$('.reset');
		return this;
	},

	identify: function() {
		this.model.identify();
	},

	resetToFactoryNew: function() {
		this.model.resetToFactoryNew();
	}
});

/**
 * View which to control touchlink commands and show scan results.
 */
app.TouchlinkView = Backbone.View.extend({
	el: '#touchlink-view',

	initialize: function() {
		this.$scan = this.$('#btn-scan');
		this.listenTo(app.TouchlinkNodes, 'add', this.addOne);
		this.listenTo(app.TouchlinkNodes, 'reset', this.render);
	},

	events: {
		'click #btn-scan': 'scan',
		'click #btn-done': 'backToMain'
	},

	render: function() {
		this.$('#node-list tbody').html('');
		app.TouchlinkNodes.each(this.addOne, this);
	},

	addOne: function(node) {
		var view = new app.TouchlinkNodeView({ model: node });
		$('#node-list tbody').append(view.render().el);
	},

	scan: function() {
		var duration = 7000; // ms
		var updateInterval = 250; // ms
		var percent = 0;
		var $bar = $('#scanProgressBar .bar')[0];
		clearAlert();

		// updates the progress bar and fetches the scan results at 100%
		var updatefn = function() {
			if (percent < 100) {
				percent += Math.abs(100 / (duration / updateInterval));
			}

			$bar.style.width = (percent % 100) + '%';

			if (percent >= 100) {
				app.TouchlinkNodes.fetch({
					success: fetchScanResultSuccess
				});
			}
			else {
				setTimeout(updatefn, updateInterval)
			}
		};

		$.post('/api/' + apikey + '/touchlink/scan', function(data) {

			$('#node-list tbody').html('');
			app.TouchlinkNodes.reset();

  			showAlert('alert-info', '<b>OK!</b> Scanning started ...');
  			
  			// show the scan progress bar
  			$bar.style.width = percent + '%';
  			$('#scanProgressBar').css('display', 'block');

  			// call progress bar update function
  			setTimeout(updatefn, updateInterval);
		})
		.fail(function(jqXHR, textStatus, errorThrown) {
			// temporary busy
			if (jqXHR.status === 503) { // Service Unavailable
				showAlert('alert-warning', '<b>Busy!</b> Please try again in a few seconds.');
			}
		});
	},

	backToMain: function() {
		window.location.assign("/");
	}
});

$(document).ready(function() {
    initBranding();
    // init fastclick
    FastClick.attach(document.body);

    // prevent default sending of form
    $('form').submit(function(e){
        e.preventDefault();
        return false;
    });

	app.TouchlinkNodes = new TouchlinkNodeCollection();
	new app.TouchlinkView();

	// there might be previous results
	app.TouchlinkNodes.fetch();
});
