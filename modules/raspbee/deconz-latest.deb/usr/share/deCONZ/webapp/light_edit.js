var MOVE_NONE = 0;
var MOVE_LEVEL = 1;
var MOVE_COLOR = 2;
var MOVE_LEFT = 3;

var EDIT_MODE_COLOR = 0;
var EDIT_MODE_COLOR_TEMPERATURE = 1;
var EDIT_MODE_MONOCHROMATIC = 2;

var colorEditMode = EDIT_MODE_COLOR;
var moveType = MOVE_NONE;
var touchType = "";
var editNeedRender = true;
var sendLevel = false;
var sendSat = false;
var sendHue = false;
var sendColorTemp = false;
var touch0 = { x: 0, y: 0 };
var touch0Prev = { x: 0, y: 0 };

var colorPos = { x: 0, y: 0 };

// relative width of dimm and color secions
var dimmWidth = 0.2;
var dimmHeight = 0.45;
var colorWidth = 0.3;
var colorHeight = 0.52;
var colorMapHeight = 100;
var hueHeight = 800; // high of hue image
// canvas color kongfu
var colorCanvas = undefined;
var colorCtx = undefined;
var pageEditWidth = undefined;
var pageEditHeight = undefined;

// touch handler
var editHammer = undefined;
var sendCheckerActive = false;
var sendCheckTimer = undefined;

var rafID = 0; // because this shall be a non-zero value

function sendCheck() {
    sendCheckTimer = undefined;

    if (!isSending) {
        sendState();
    }

    if (sendCheckerActive) {
        sendCheckTimer = setTimeout(sendCheck, 1000);
    }
}

function stopSendCheck() {
    sendCheckerActive = false;
    if (sendCheckTimer !== undefined) {
        clearTimeout(sendCheckTimer);
        sendCheckTimer = undefined;
    }
}

function sendState() {
    if (sendLevel || sendSat || sendHue || sendColorTemp) {
        var out = { };
        out.type = curEdit.obj.type;
        out.id = curEdit.obj.id;
        out.transitiontime = 9;

        // send level to device
        if (sendLevel) {
            sendLevel = false;
            out.on = curEdit.obj.state.on;
            out.bri = curEdit.level;
        }

        if (sendHue || sendSat) {
            var rgb = HSVtoRGB(curEdit.hue, curEdit.sat / 255, curEdit.levelPercent / 100);
            out.xy = rgbToXy(rgb[0], rgb[1], rgb[2]);
        }

        if (sendSat) {
            sendSat = false;
            out.sat = curEdit.sat;
        }

        if (sendHue) {
            sendHue = false;
            out.hue = Math.floor(curEdit.hue * 360.0 * 182.0444);
        }

        if (sendColorTemp) {
            sendColorTemp = false;
            out.ct = curEdit.ct;
        }

        pushObjState(out);
    }
}

function setObjName(input) {
    var putUrl;
    var out = {};

    if (input.value === undefined) {
        console.log("no valid input field");
        return;
    }

    out.name = input.value;

    if (curEdit.obj.type === TYPE_LIGHT) {
        putUrl = '/api/' + apikey + '/lights/' + curEdit.obj.id;
    }
    else if (curEdit.obj.type === TYPE_GROUP) {
        putUrl = '/api/' + apikey + '/groups/' + curEdit.obj.id;
    }

    $.ajax({
        url: putUrl,
        type: 'PUT',
        cache: false,
        contentType: 'application/json; charset=utf-8',
        data: JSON.stringify(out),
        dataType: 'json',
        success: function(data) {
            console.log("renamed to " + out.name);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log("textStatus:", textStatus + ' ' + errorThrown);
            console.log(jqXHR.responseText);
        },
        timeout: 10000
    });
}

// Support iOS virtual keyboard "done" button
function onLightEditBlur(e) {
    if (e.target.nodeName === "INPUT") {
        setObjName(e.target);
    }
}

// Desktop and Android enter key
function onLightEditKeyup(e) {
    if (e.keyCode === 13) { // enter
        if (e.target.nodeName === "INPUT") {
            e.target.blur();
            //setObjName(e.target); // will be handled by blur handler
        }
    }
}

/**
 * Prevent bounce effect then scrolling the top/bottom parts on a mobile device.
 */
function initPreventBouncing() {
    // pageLightEdit only takes 2/3 of the whole screen
    // prevent bouncing if touch dragging in the footer area
    if (Modernizr.touch) {
        document.addEventListener('touchstart', function(e) {
            if (e.changedTouches[0].pageY > pageLightEdit.clientHeight) {
                e.preventDefault();
            }
        });

        document.addEventListener('touchmove', function(e) {
            if (e.changedTouches[0].pageY > pageLightEdit.clientHeight) {
                e.preventDefault();
            }
        });
    }
}

function initEditPage() {

    initPreventBouncing();
    //colorCanvas = document.createElement('canvas');
    //colorCtx = colorCanvas.getContext('2d');
    pageEditWidth = pageLightEdit.clientWidth;

    // touch handler
    editHammer = new Hammer(pageLightEdit, {
        drag_min_distance: 1,
        prevent_default: true,
        swipe: false,
        drag_horizontal: false,
        transform: false,
        hold: false
    });

    editHammer.ontap = function(e) {
      var el = e.originalEvent.target;
      var action = $(el).data("action");

      if (el.nodeName == 'INPUT') {
        el.focus();
        return true;
      }

      if (el.parentNode.id === 'satStateLabel') {
        if (colorEditMode === EDIT_MODE_COLOR) {
            switchColorEditMode(EDIT_MODE_COLOR_TEMPERATURE);
        }
        else if (colorEditMode === EDIT_MODE_COLOR_TEMPERATURE) {
            switchColorEditMode(EDIT_MODE_COLOR);
        }
      }

      if (el.nodeName == 'A') {
        // stopSendCheck();

        if (Modernizr.sessionstorage) {
            // update config object and put into localsession storage
            if (typeof(config) === 'object') {
                if (lightId && (lightId in config.lights)) {
                    config.lights[lightId].on = curEdit.obj.state.on;
                    config.lights[lightId].hue = curEdit.obj.state.hue;
                    config.lights[lightId].bri = curEdit.obj.state.bri;
                    config.lights[lightId].sat = curEdit.obj.state.sat;
                    config.lights[lightId].ct = curEdit.obj.state.ct;
                    sessionStorage.config = JSON.stringify(config);
                }
            }
        }

        setTimeout(function() {
            location.assign(el.href);
        }, 100);
        return true;
      }

      if (action !== undefined) {
          if (action === "close") {
              stopSendCheck();
              location.href = '/'; // go back but reload dynamic data
          }
      }

      e.originalEvent.preventDefault();
    };

    editHammer.ondoubletap = function(e) {
        e.originalEvent.preventDefault();
    };

    editHammer.ondragend = function(e) {
        touchType = e.originalEvent.type;
        touch0Prev.x = touch0.x;
        touch0Prev.y = touch0.y;

        editNeedRender = true;
        e.originalEvent.preventDefault();
    };

    editHammer.onrelease = function(e) {
        var el = e.originalEvent.target;
        touchType = e.originalEvent.type;
        editNeedRender = true;
        setIsEditing(false);
        moveType = MOVE_NONE;

        if (el.nodeName == 'A') {
            return;
        }

        sendState();


        if (el !== devNameLabel) {
            e.originalEvent.preventDefault();
        }
    };

    editHammer.ondragstart = function(e) {
        if (Modernizr.touch) {
            touch0.x = e.originalEvent.changedTouches[0].pageX;
            touch0.y = e.originalEvent.changedTouches[0].pageY;
        }
        else {
            touch0.x = e.originalEvent.pageX;
            touch0.y = e.originalEvent.pageY;
        }
        touch0Prev.x = touch0.x;
        touch0Prev.y = touch0.y;

        setIsEditing(true);

        var x = touch0.x - pageLightEdit.offsetLeft;

        pageEditWidth = pageLightEdit.clientWidth;

        if (x <= pageEditWidth * 0.259) {
            moveType = MOVE_LEFT;
            // console.log('move saturation');
        }
        else if (x <= pageEditWidth * 0.630) {
            moveType = MOVE_COLOR;
            // console.log('move color');
        }
        else if (x <= pageEditWidth) {
            moveType = MOVE_LEVEL;
            // console.log('move level');
        }

        touchType = e.originalEvent.type;
        editNeedRender = true;
        e.originalEvent.preventDefault();
    };

    editHammer.ondrag = function(e) {
        touchType = e.originalEvent.type;
        if (Modernizr.touch) {
            touch0.x = e.originalEvent.changedTouches[0].pageX;
            touch0.y = e.originalEvent.changedTouches[0].pageY;
        }
        else {
            touch0.x = e.originalEvent.pageX;
            touch0.y = e.originalEvent.pageY;
        }
        editNeedRender = true;
        e.originalEvent.preventDefault();
    };
}

/**
 * Converts RGB to CIE 1931 xy values
 * All in- and outputs are in the range 0..1
 * @param  {Number} r red color.
 * @param  {Number} g green color.
 * @param  {Number} b blue color.
 * @returns {Array} The x and y coordinates [x,y].
 */
function rgbToXy(r, g, b) {

   var X = 0.412453 * r + 0.357580 * g + 0.180423 * b;
   var Y = 0.212671 * r + 0.715160 * g + 0.072169 * b;
   var Z = 0.019334 * r + 0.119193 * g + 0.950227 * b;

   var x = X / (X + Y + Z);
   var y = Y / (X + Y + Z);
   return [ x, y ];
}

/**
 * Converts HSV to RGB
 * All in- and outputs are in the range 0..1
 * @param  {Number} h hue.
 * @param  {Number} s saturation.
 * @param  {Number} v value.
 * @returns {Array} The RGB array [r,g,b].
 */
function HSVtoRGB(h, s, v) {
    var r, g, b, i, f, p, q, t;

    i = Math.floor(h * 6);
    f = h * 6 - i;
    p = v * (1 - s);
    q = v * (1 - f * s);
    t = v * (1 - (1 - f) * s);
    switch (i % 6) {
        case 0: r = v, g = t, b = p; break;
        case 1: r = q, g = v, b = p; break;
        case 2: r = p, g = v, b = t; break;
        case 3: r = p, g = q, b = v; break;
        case 4: r = t, g = p, b = v; break;
        case 5: r = v, g = p, b = q; break;
    }
    return [r, g, b];
}

function rgb2hsv (r,g,b) {
 var computedH = 0;
 var computedS = 0;
 var computedV = 0;

 //remove spaces from input RGB values, convert to int
 var r = parseInt( (''+r).replace(/\s/g,''),10 );
 var g = parseInt( (''+g).replace(/\s/g,''),10 );
 var b = parseInt( (''+b).replace(/\s/g,''),10 );

 if ( r==null || g==null || b==null ||
     isNaN(r) || isNaN(g)|| isNaN(b) ) {
   alert ('Please enter numeric RGB values!');
   return;
 }
 if (r<0 || g<0 || b<0 || r>255 || g>255 || b>255) {
   alert ('RGB values must be in the range 0 to 255.');
   return;
 }
 r=r/255; g=g/255; b=b/255;
 var minRGB = Math.min(r,Math.min(g,b));
 var maxRGB = Math.max(r,Math.max(g,b));

 // Black-gray-white
 if (minRGB==maxRGB) {
  computedV = minRGB;
  return [0,0,computedV];
 }

 // Colors other than black-gray-white:
 var d = (r==minRGB) ? g-b : ((b==minRGB) ? r-g : b-r);
 var h = (r==minRGB) ? 3 : ((b==minRGB) ? 1 : 5);
 computedH = 60*(h - d/(maxRGB - minRGB));
 computedS = (maxRGB - minRGB)/maxRGB;
 computedV = maxRGB;
 return [computedH,computedS,computedV];
}

function calcColor() {
    var dx = touch0.x - touch0Prev.x;
    var dy = touch0.y - touch0Prev.y;

    touch0Prev.x = touch0.x;
    touch0Prev.y = touch0.y;

    colorPos.y += dy;

    var imgy = colorPos.y % hueHeight;

    if (imgy < 0) {
        imgy = hueHeight + imgy;
    }

    var pos = (hueHeight - imgy) / hueHeight;

    curEdit.hue = pos;

    if (curEdit.hue > 1)
      curEdit.hue = 1;
    else if (curEdit.hue < 0)
      curEdit.hue = 0;

    curEdit.obj.hue = curEdit.hue;
    curEdit.obj.state.hue = curEdit.hue * 360.0 * 182.0444;
}

// recalculate level based on dy of single finger drag
function calcLevel() {
//    var dx = touch0.x - touch0Prev.x;
    var dy = touch0.y - touch0Prev.y;

    touch0Prev.x = touch0.x;
    touch0Prev.y = touch0.y;

    if (dy !== 0) {
        var accel = 1.0;
        curEdit.levelPercent -= 100 * (dy * accel) / pageEditHeight;
    }

    if (curEdit.levelPercent < 0)
        curEdit.levelPercent = 0;
    else if (curEdit.levelPercent > 100)
        curEdit.levelPercent = 100;

    curEdit.level = Math.floor(curEdit.levelPercent / 100 * 255);

    if (curEdit.level < 0)
      curEdit.level = 0;
    else if (curEdit.level > 255)
      curEdit.level = 255;

    curEdit.obj.levelPercent = curEdit.levelPercent;
    curEdit.obj.level = curEdit.level;
    curEdit.obj.state.bri = curEdit.level;

    // check if level changed on/off state
    if (curEdit.level === 0) {
        curEdit.obj.state.on = false;
    }
    else {
        curEdit.obj.state.on = true;
    }

    sendLevel = true;
}

// recalculate level based on dy of single finger drag
function calcSaturation() {
//    var dx = touch0.x - touch0Prev.x;
    var dy = touch0.y - touch0Prev.y;

    touch0Prev.x = touch0.x;
    touch0Prev.y = touch0.y;

    if (dy !== 0) {
        var accel = 1.0;
        curEdit.satPercent -= 100 * (dy * accel) / pageEditHeight;
    }

    curEdit.sat = Math.floor(curEdit.satPercent / 100 * 255);

    if (curEdit.satPercent < 0)
        curEdit.satPercent = 0;
    else if (curEdit.satPercent > 100)
        curEdit.satPercent = 100;

    if (curEdit.sat < 0)
      curEdit.sat = 0;
    else if (curEdit.sat > 255)
      curEdit.sat = 255;

    curEdit.obj.satPercent = curEdit.satPercent;
    curEdit.obj.sat = curEdit.sat;
    curEdit.obj.state.sat = curEdit.sat;
}

// recalculate color temperature based on dy of single finger drag
function calcColorTemperature() {
    var ctMin = 153;
    var ctMax = 500;
    var dy = touch0.y - touch0Prev.y;

    touch0Prev.x = touch0.x;
    touch0Prev.y = touch0.y;

    if (dy !== 0) {
        var accel = 1.0;
        curEdit.ctPercent -= 100 * (dy * accel) / pageEditHeight;
    }

    if (curEdit.ctPercent < 0)
        curEdit.ctPercent = 0;
    else if (curEdit.ctPercent > 100)
        curEdit.ctPercent = 100;

    var norm = curEdit.ctPercent / 100;
    var ct = (norm * (ctMax - ctMin)) + ctMin;

    if (ct < ctMin)
      ct = ctMin;
    else if (ct > ctMax)
      ct = ctMax;
  
    curEdit.ct = ct;
    curEdit.obj.state.ct = ct;
}

function renderLevel() {
    if (curEdit.obj.state.on === false) {
        levelStateLabelValue.innerHTML = "Off";
        curEdit.levelPercent = 0;
    }

    var level = curEdit.levelPercent > 0 ? curEdit.levelPercent : 1;
    var dh = (canvas0ClientHeight * 0.9) * (level / 100);
    var dy = (canvas0ClientHeight / 2) - (dh / 2);

    levelStateLabelValue.innerHTML = Math.floor(curEdit.levelPercent) + "%";

    var val = "";

    // never hide the bar completely
    var displLevel = (curEdit.levelPercent > 5) ? curEdit.levelPercent : 5; 

    if (Modernizr.csstransforms3d) {
        val = 'scale3d(1,' + displLevel / 100 + ', 1)';
    }
    else if (Modernizr.csstransforms) {
        val = 'scale(1,' + displLevel / 100 + ')';
    }

    barLevel.style[transformProp] = val;
}

function renderLeftBar() {
    var percent = 0;
    var label = 0;
    if (colorEditMode === EDIT_MODE_COLOR) {
        percent = curEdit.satPercent > 0 ? curEdit.satPercent : 1;
        label = curEdit.satPercent;
    }
    else if (colorEditMode === EDIT_MODE_COLOR_TEMPERATURE) {
        percent = curEdit.ctPercent > 0 ? curEdit.ctPercent : 1;   
        label = curEdit.ctPercent;
    }

    var dh = (canvas0ClientHeight * 0.9) * (percent / 100);
    var dy = (canvas0ClientHeight / 2) - (dh / 2);

    satStateLabelValue.innerHTML = Math.floor(label) + "%";

    var val = "";

    // never hide the bar completely
    var displSat = (label > 5) ? label : 5; 

    if (Modernizr.csstransforms3d) {
        val = 'scale3d(1,' + displSat / 100 + ', 1)';
    }
    else if (Modernizr.csstransforms) {
        val = 'scale(1,' + displSat / 100 + ')';
    }

    barSat.style[transformProp] = val;
}

function renderHue() {
    colorMap.style.backgroundPosition = Math.floor(colorPos.x) + "px " + Math.floor(colorPos.y) + "px";
}

function renderDimmEdit(t) {
    if (!editNeedRender) {
        cancelRequestAnimFrame(rafID);
        rafID = requestAnimationFrame(renderDimmEdit);
        return;
    }

    editNeedRender = false; // mark as rendered

    if (moveType === MOVE_LEVEL) {
        calcLevel();
        renderLevel();
    }
    else if (moveType === MOVE_COLOR) {
        calcColor();
        if (colorEditMode === EDIT_MODE_COLOR) {
            sendSat = true;
            sendHue = true;
        }
        renderHue();
    }
    else if (moveType === MOVE_LEFT) {
    
        if (colorEditMode === EDIT_MODE_COLOR) {
            calcSaturation();
            sendSat = true;
            sendHue = true;
        }
        else if (colorEditMode === EDIT_MODE_COLOR_TEMPERATURE) {
            calcColorTemperature();
            sendColorTemp = true;
        }
        renderLeftBar();
    }

    cancelRequestAnimFrame(rafID);
    rafID = requestAnimationFrame(renderDimmEdit);
}

function adjustLevelEditPage() {
    if ($(pageLightEdit).hasClass('hidden')) {
        return;
    }

    var pageHeight = $(pageLightEdit).innerHeight();

    canvas0ClientWidth = 48;
    canvas0ClientHeight = Math.floor(pageHeight * dimmHeight);

    barLevel.style.top  = "15%";
    barLevel.style.right  = "36px";
    //barLevel.width  = canvas0ClientWidth;
    // barLevel.height = canvas0ClientHeight;
    // barLevel.style.width  = canvas0ClientWidth + "px";
    // barLevel.style.height = canvas0ClientHeight + "px";
    barLevel.style.height = "45%";

    // copy to shadow div
    var barLevelShd = document.getElementById('barLevelShd');
    barLevelShd.style.top = barLevel.style.top;
    barLevelShd.style.right = barLevel.style.right;
    barLevelShd.style.height = barLevel.style.height;
    barLevelShd.height = barLevel.height;

    barSat.style.top  = "15%";
    barSat.style.left  = "36px";
    // barSat.width  = canvas0ClientWidth;
    // barSat.height = canvas0ClientHeight;
    // barSat.style.width  = canvas0ClientWidth + "px";
    // barSat.style.height = canvas0ClientHeight + "px";
    barSat.style.height = "45%";

    // copy to shadow div
    var barSatShd = document.getElementById('barSatShd');
    barSatShd.style.top = barSat.style.top;
    barSatShd.style.left = barSat.style.left;
    barSatShd.style.height = barSat.style.height;
    barSatShd.height = barSat.height;

    canvasColorClientWidth = Math.floor(winInnerWidth * colorWidth);
    canvasColorClientHeight = Math.floor(winInnerHeight * colorHeight);
    canvasColorClientWidth = 30;
    canvasColorClientHeight = 50;

    colorMap.width  = canvasColorClientWidth;
    colorMap.height = canvasColorClientHeight;
    colorMap.style.top  = "15%";
    colorMap.style.left  = 35 + "%";
    colorMap.style.width  = canvasColorClientWidth + "%";
    colorMap.style.height = canvasColorClientHeight + "%";

    // footer fixed at the bottom
    //pageLightEdit.style.height = winInnerHeight + "px";

    //var footerWidth = footer.clientWidth;
    pageEditWidth = pageLightEdit.clientWidth;
    pageEditHeight = pageLightEdit.clientHeight;
    //footer.style.left = ((pageEditWidth / 2) - (footerWidth / 2)) + "px";
}

function lightEditSetHue(hue) {
  colorPos.y = hueHeight - (hueHeight * hue);
}

/**
 * Color edit mode switcher.
 * @param  {Number} mode the new color edit mode.
 */
function switchColorEditMode(mode) {
    colorEditMode = mode;
   
    if (colorEditMode === EDIT_MODE_COLOR) {
        colorMap.style.visibility = "";
        barSat.style.visibility = "";
        barSatShd.style.visibility = "";
        $('#satStateLabel')[0].style.visibility = "";
        $('#satStateLabel p').html('Sat');
    }
    else if (colorEditMode === EDIT_MODE_MONOCHROMATIC) {
        colorMap.style.visibility = "hidden";
        barSat.style.visibility = "hidden";
        barSatShd.style.visibility = "hidden";
        $('#satStateLabel')[0].style.visibility = "hidden";
    }
    else if (colorEditMode === EDIT_MODE_COLOR_TEMPERATURE) {
        colorMap.style.visibility = "hidden";
        barSat.style.visibility = "";
        barSatShd.style.visibility = "";
        $('#satStateLabel')[0].style.visibility = "";
        $('#satStateLabel p').html('Temp');
    }
}

function showLightEditPage() {
  $(document.body).addClass("darkBg");
  $(pageLightEdit).removeClass("pageHide");
  winInnerWidth = window.innerWidth;
  winInnerHeight = window.innerHeight;
  moveType = MOVE_NONE;

  detectVendorPrefixes();

  curPage = pageLightEdit;

  var hue = 0;

  if (curEdit.obj.state.hue) {
    hue = curEdit.obj.state.hue / 182.04444;
    hue = hue / 360;
    if (hue < 0) {
        hue = 0;
    }
    else if (hue > 1) {
        hue = 1;
    }
    curEdit.obj.hue = hue;
  }

  lightEditSetHue(hue);
  colorMap.style.backgroundPosition = colorPos.x + "px " + colorPos.y + "px";
  colorMapHeight = colorMap.clientHeight;

  sendLevel = false;
  sendSat = false;
  sendHue = false;
  sendColorTemp = false;
  devNameLabel.value = curEdit.obj.name;
  curEdit.levelPercent = curEdit.obj.levelPercent;
  curEdit.satPercent = curEdit.obj.satPercent;
  curEdit.ctPercent = curEdit.obj.ctPercent;
  curEdit.hue = curEdit.obj.hue;
  curEdit.sat = curEdit.obj.state.sat;

  var mode = EDIT_MODE_COLOR;

  if (curEdit.obj.state.colormode == 'ct') {
      mode = EDIT_MODE_COLOR_TEMPERATURE;
  }
  else if (curEdit.obj.modelid && curEdit.obj.modelid.indexOf("FLS-H") != -1) {
      mode = EDIT_MODE_COLOR_TEMPERATURE;
  }
  else if (!curEdit.obj.hasColor) {
      mode = EDIT_MODE_MONOCHROMATIC;
  }

  switchColorEditMode(mode);

  editNeedRender = true;
  renderLevel();
  renderHue();
  renderLeftBar();

  cancelRequestAnimFrame(rafID);
  rafID = requestAnimationFrame(renderDimmEdit);

  $(colorMap).removeClass('colorMapHidden');

    document.addEventListener("blur", onLightEditBlur, true);
    document.addEventListener("keyup", onLightEditKeyup, true);

    sendCheckerActive = true;
    sendCheck();
    devNameLabel.blur();

    // hide url bar
    setTimeout(function () {
        window.scrollTo(0, 1);
    }, 10);
}

function hideLightEditPage() {
    sendCheckerActive = false;
    $(document.body).removeClass("darkBg");
    sendLevel = false;

    $(pageLightEdit).addClass("pageHide");
  //document.removeEventListener('touchstart', editOnTouchStart);
  //document.removeEventListener('touchend', editOnTouchEnd);
  //document.removeEventListener('touchmove', editOnTouchMove);
    document.removeEventListener("blur", onLightEditBlur, true);
    document.removeEventListener("keyup", onLightEditKeyup, true);
}
