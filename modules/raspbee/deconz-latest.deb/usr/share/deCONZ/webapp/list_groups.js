var groupArr = [];

function getGroupByRgid(rgid) {
    for (var i = 0; i < groupArr.length; i++) {
        if (groupArr[i].rgid === rgid) {
            return groupArr[i];
        }
    }

    return undefined;
}

function recalcAllGroupParams() {
    for (var i = 0; i < groupArr.length; i++) {
        mapLevelToPercent(groupArr[i]);
        mapSatToPercent(groupArr[i]);
    }
}

function copyGroup(dst, src) {
    if (src.name !== undefined) {
        dst.name = src.name;
    }

    if (src.pgid !== undefined) {
        dst.pgid = src.pgid;
    }

    if (src.rgid !== undefined) {
        dst.rgid = src.rgid;
    }

    if (src.updateId !== undefined) {
        dst.updateId = src.updateId;
    }

    if (src.isLocation !== undefined) {
        dst.isLocation = src.isLocation;
    }

    if (src.isSubGroup !== undefined) {
        dst.isSubGroup = src.isSubGroup;
    }

    if (src.on !== undefined) {
        dst.on = src.on;
    }

    if (src.hue !== undefined) {
        dst.hue = src.hue;
    }

    if (src.sat !== undefined) {
        dst.sat = src.sat;
    }

    if (src.satPercent !== undefined) {
        dst.satPercent = src.satPercent;
    }

    if (src.level !== undefined) {
        dst.level = src.level;
    }

    if (src.levelPercent !== undefined) {
        dst.levelPercent = src.levelPercent;
    }

}

function updateGroupUi(group) {
    var el = $('div.location[data-gid="' + group.id + '"]').each(function() {

    });
}

function lightToHtml(light) {
    mapLevelToPercent(light);
    var onOffClass = (light.state.on && light.state.reachable) ? "light_on " : "";
    var reachableClass = light.state.reachable ? " " : "not_reachable ";
    var txt = "";
    txt += "<tr class=\"" + reachableClass + "light_item\" data-lid=\"" + light.id + "\">";
    txt += "<td class=\"" + onOffClass + "onoff_button\" data-lid=\"" + light.id + "\"></td>";
    txt += "<td class=\"light_level\">" + light.levelPercent + "%</td>";
    txt += "<td class=\"name\">" + light.name + "</td>";
    txt += "<td class=\"edit_button\" data-lid=\"" + light.id + "\"></td>";
    txt += "</tr>";
    return txt;
}

function groupToHtml(group, lights) {
    var btnSize = isDesktop ? "" : "btn-large";

    var txt = '<div class="location span6" data-gid="' + group.id + '">';

    txt += '<table><thead><th></th><th></th><th></th><th></th></thead>';
    txt += '<tbody>';
    txt += '<tr>';
    txt += '<td colspan="3" class="locName lightFont">' + group.name + '</td>';
    txt += '<td class="edit_button edit_group" data-gid="' + group.id + '"></td>';
    txt += '</tr>';

    for (var i = 0; i < group.lights.length; i++) {
        var light = lights[group.lights[i]];

        if (light !== undefined) {
            txt += lightToHtml(light);
        }
    }
    txt += '</tbody>';
    txt += '</table>';

    txt += '<span class="btn ' + btnSize + ' actionButton onButton" data-gid="' + group.id + '" data-action="on">on</span>';
    txt += '<span class="btn ' + btnSize + ' actionButton offButton" data-gid="' + group.id + '" data-action="off">off</span>';

    if (group.scenes !== undefined) {
        for (var i = 0; i < group.scenes.length; i++) {
            var scene = group.scenes[i];
            txt += '<span class="btn ' + btnSize + ' actionButton" data-gid="' + group.id + '" data-sid="' + scene.id + '" data-action="callscene">' + scene.name + '</span>';
        }
    }

    txt += '<span class="btn ' + btnSize + ' actionButton editScenesButton" data-gid="' + group.id + '">...</span>';
    txt += '</div>';
    return txt;
}

function addGroupToUi(group, lights, rowtxt) {
    group.type = TYPE_GROUP;
    group.hasColor = true;
    group.state = group.action;

    rowtxt += groupToHtml(group, lights);
    groupArr.push(group);

    return rowtxt;
}

/**
 * Helper to adjust the size of the name field to not exceed the table size.
 */
function adjustLightNames() {
    $('.location').each(function(index) {
        if (index > 0) {
            var maxwidth = $(this).innerWidth() - 180;
            $('.light_item td:nth-child(3)').each(function(index) {
                $(this).css('max-width', maxwidth + 'px');
            });
        }
    });
}

// build and show device list ui
function checkGroups(groups) {
    var groupCount = 0;

    // compatibility to to older API
    for (var g in groups) {
        groups[g].id = g;
        groups[g].rgid = g;
        groupCount++;
    }

    if (groupCount === 0) {
        var txt = '<br/><div class="alert alert-info"><b>Attention!</b> ';
        txt += 'Currently no groups are defined.<br/>';
        txt += '</div>';
        txt += '<p>In order to see and control the lights:</p>';
        txt += '<ol>';
        txt += '<li>Click on Settings/Groups and create a group</li>';
        txt += '<li>Add some lights to the new group</li>';
        txt += '<li>Click on done to come back here</li>';
        txt += '</ol>';
        pageLightList.innerHTML = txt;
        return;
    }

    // check for group updates
    for (var i = 0; i < groupArr.length; i++) {
        var g = groupArr[i];
        var found = false;

        for (var id in groups) {
            var g2 = groups[id];

            if (g.id === g2.id) {
                mapLevelToPercent(g2);
                mapSatToPercent(g2);
                copyGroup(g, g2);
                found = true;
                break;
            }
        }
    }

    // check if group is new
    var k = 0;
    var rowtxt = "";
    for (var id in groups) {
        var gnew  = groups[id];


        if ((k % 2) === 0) {
            rowtxt += '<div class="row-fluid">';
        }

        var gnum = $('div.location[data-gid="' + gnew.id + '"]').length;

        if (gnum === 0) {
            rowtxt = addGroupToUi(gnew, config.lights, rowtxt);
            k++;
        }


        if ((k % 2) === 0) {
            rowtxt += '</div>';
        }
    }

    // uneven group count
    if ((k % 2) === 1) {
        rowtxt += '</div>';
    }

    pageLightList.innerHTML += rowtxt;

    adjustLightNames();
}
