
// a list of all lights
var lightArr = [];
var pageLightListScrollY = 0;

function recalcAllLevels(lights) {
    for (var i = 0; i < lights.length; i++) {
        mapLevelToPercent(lights[i]);
        mapSatToPercent(lights[i]);
    }
};

function copyLight(dst, src) {
    if (src.name !== undefined) {
        dst.name = src.name;
    }

    if (src.state.on !== undefined) {
        dst.state.on = src.state.on;
    }

    if (src.state.hue !== undefined) {
        dst.state.hue = src.state.hue;
    }

    if (src.state.sat !== undefined) {
        dst.state.sat = src.state.sat;
    }

    if (src.state.satPercent !== undefined) {
        dst.state.satPercent = src.state.satPercent;
    }

    if (src.state.bri !== undefined) {
        dst.state.bri = src.state.bri;
    }

    if (src.state.levelPercent !== undefined) {
        dst.state.levelPercent = src.state.levelPercent;
    }
};

/*
function addLighToUi(light, idx) {
        if (light.state.sat === undefined) {
            light.state.sat = 0;
            light.state.satPercent = 0;
        }

        if (light.state.hue === undefined) {
            light.state.hue = 0;
        }

        if (light.state.reachable !== undefined) {
            if (light.state.reachable === false) {
                return;
            }
        }

        if (light.devType !== undefined) {
            switch (light.devType) {
                case "Dimmable Light":
                    light.hasColor = false;
                    break;
                default:
                    light.hasColor = true;
                    break;
            }
        }

        if (light.hasColor === undefined) {
            light.hasColor = false;
        }

        var onOffClass = light.state.on ? "light_on " : "";
        var reachableClass = light.state.reachable ? " " : "not_reachable";
        var txt = "<li class=\"light_item\" data-lidx=\"" + idx + "\"><span class=\"" + onOffClass + reachableClass + "onoff_button\" data-lidx=\"" + idx + "\"></span><span class=\"light_level\">" + light.levelPercent + "%</span><span class=\"name\">" + light.name + "</span><span class=\"edit_button\" data-lidx=\"" + idx + "\"></span></li>";
        light.type = TYPE_LIGHT;

        var el = getLocationGroupElement(light.groups);
        var ul = $('.devices', el)[0];

        ul.innerHTML += txt;

        light.elem = $('li.light_item[data-lid="' + idx + '"]', ul)[0];
};
*/

// build and show device list ui
/*
function showDeviceList(lights) {
	//var txt = "";

	//txt += "<li class=\"dev_location\">Wohnzimmer</li>";

    // check if lights were updated
    for (var i = 0; i < lightArr.length; i++) {
        var l = lightArr[i];
        var found = false;

        for (var id in lights) {
            var l2 = lights[id];

            if (l.id === l2.id) {
                if (l.updateId !== l2.updateId) {
                    copyLight(l, l2);
                    found = true;
                    break;
                }
            }
        }

        if (!found) {
            l.available = false;
        }
    }

    // check for new lights
    for (var id in lights) {
        var lnew = lights[id]; // might be new light
        var isNew = true;

        for (var j = 0; j < lightArr.length; j++) {
            var l = lightArr[j];

            if (l.id === lnew.id) {
                isNew = false;
            }
        }

        if (isNew) {
            lightArr.push(lnew);
            addLighToUi(lnew, (lightArr.length - 1));
        }
    }

    //deviceList.innerHTML = txt;
};*/

// check for changes and update device list ui
function updateDeviceListUi() {
    for (var i = 0; i < lightArr.length; i++) {
        
        $('.light_item').each(function() {
            if (this.dataset.lidx !== undefined) {
                var lidx = this.dataset.lidx;
                var light = lightArr[lidx];
                var onOffButton = $('.onoff_button', this);
                var levelLabel = $('.light_level', this);

                if (light.state.on === true) {
                    $(onOffButton).addClass('light_on');
                }
                else {
                    $(onOffButton).removeClass('light_on');   
                }

                levelLabel.text(Math.ceil(light.state.levelPercent) + '%');

                var nameLabel = $('.name', this);
                if (nameLabel.text() !== light.name) {
                    nameLabel.text(light.name);
                }
            }
        });
    }
}

// update lights
function updateLights() {
    var lights = [];
    if (config && config.lights) {
        for (var id in config.lights) {
            var l = config.lights[id];
            l.type = TYPE_LIGHT;
            l.id = id;
            mapLevelToPercent(l);
            mapSatToPercent(l);
        }
    }
}

function getHiddenProp(){
    var prefixes = ['webkit','moz','ms','o'];
    
    // if 'hidden' is natively supported just return it
    if ('hidden' in document) return 'hidden';
    
    // otherwise loop over all the known prefixes until we find one
    for (var i = 0; i < prefixes.length; i++){
        if ((prefixes[i] + 'Hidden') in document) 
            return prefixes[i] + 'Hidden';
    }

    // otherwise it's not supported
    return null;
}

// check if lights are updated on the server
function checkUpdateLights() {
        return; // TODO reactivate with new API
};

function showLightListPage() {
    curPage = pageLightList;

    //pageLightList.style.visibility = 'visible';
    // pageLightList.style.display = 'block';
    $(pageLightList).removeClass("pageHide");

    if (needReload) {
        needReload = false;
        var forceGet = true;
        location.reload(forceGet);
    }
}

function hideLightListPage() {
    pageLightListScrollY = window.scrollY;
    //pageLightList.style.visibility = 'hidden';
    // pageLightList.style.display = 'none';
    $(pageLightList).addClass("pageHide");
}

