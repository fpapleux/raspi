function displayNetworkSetting(config) {

    var up = config.config["rfconnected"];

    if (up) {
        $('#networkUpCheckbox').attr('checked', 'checked');
    }
    else {
        $('#networkUpCheckbox').removeAttr('checked');
    }

    var permitJoin = config.config["permitjoin"];

    if (permitJoin > 0) {
        $('#permitJoinCheckbox').attr('checked', 'checked');
    }
    else {
        $('#permitJoinCheckbox').removeAttr('checked');
    }

    var otauActive = config.config["otauactive"];

    if (otauActive) {
        $('#otauActiveCheckbox').attr('checked', 'checked');
    }
    else {
        $('#otauActiveCheckbox').removeAttr('checked');
    }
}

// get full configuration 
function getFullConfiguration() {

    $.ajax({
        url: 'api/' + apikey,
        dataType: 'json',
        type: 'GET',
        cache: false,
        contentType: 'application/json; charset=utf-8',
        headers: { 'Accept': apiversion },
        success: function(json) {
            clearAlert();
            displayNetworkSetting(json);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            switch (jqXHR.status) {
            case 403:
                window.location.assign("/login.html");
                break;

            default:
                setTimeout(getFullConfiguration, 1000);
                showAlert('alert-error', '<b>Error!</b> Lost connection, retry in one second ...');
                break;
            }
        },
        timeout: 10000
    });

};

function createGroup(name) {

    $.ajax({
        url: 'api/' + apikey + '/groups',
        dataType: 'json',
        type: 'POST',
        cache: false,
        contentType: 'application/json; charset=utf-8',
        headers: { 'Accept': apiversion },
        data: "{ \"name\": \"" + name + "\" }",
        success: function(json) {
            location.href = 'edit_groups.html';
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log("textStatus:", textStatus + ' ' + errorThrown);
            console.log(jqXHR.responseText);
            //setTimeout(updateLights, 15000);
        }//,
        //timeout: 2000,
    });
}

function onSubmit() {
    var params = {
        "rfconnected" : false,
        "permitjoin" : 0,
        "otauactive" : false
    };

    if ($('#networkUpCheckbox').prop('checked')) {
        params.rfconnected = true;
    }

    if ($('#permitJoinCheckbox').prop('checked')) {
        params.permitjoin = 255;
    }

    if ($('#otauActiveCheckbox').prop('checked')) {
        params.otauactive = true;
    }

    $.ajax({
        url: 'api/' + apikey + '/config',
        dataType: 'json',
        type: 'PUT',
        contentType: 'application/json; charset=utf-8',
        headers: { 'Accept': apiversion },
        data: JSON.stringify(params),
        success: function(json) {
            showAlert('alert-success', '<b>OK!</b> Updated configuration.');
        },
        error: function(jqXHR, textStatus, errorThrown) {
            showAlert('alert-error', '<b>Error!</b> Failed to update configuration.');
        }
    });
}
