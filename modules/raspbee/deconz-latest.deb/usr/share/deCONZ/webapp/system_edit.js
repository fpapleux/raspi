var updateTimerId;
var updateDots = "";

function displaySetting(config) {
    var swversion = config.config.swversion;

    if (config.config.updatechannel !== 'stable') {
        swversion += ' <span class="label label-info">' + config.config.updatechannel + '</span>';
    }

    $('#gwSwVersion').html(swversion);
    $('#gwNameInput').val(config.config.name);
    $('#gwGroupDelayInput').val(config.config.groupdelay);

    var discovery = config.config.discovery;

    if (discovery === true) {
        $('#internetServiceCheckbox').attr('checked', 'checked');
    }
    else {
        $('#internetServiceCheckbox').removeAttr('checked');
    }

    var curVersion = config.config.swversion;
    var updateVersion = config.config.swupdate.version;
    
    var updateTxt = "";
    if (compareVersionNumbers(curVersion, updateVersion) === -1)
    {
        updateTxt = '<button class="btn" type="bytton" onclick="updateSoftware(); return false;"><b>update to</b> ' + config.config.swupdate.version + ' </button>';
    }
    else if (config.config.fwneedupdate) {
        updateTxt = '<button class="btn" type="bytton" onclick="updateFirmware(); return false;"><b>update firmware</b></button>';
    }
    
    $('#gwSwUpdate').html(updateTxt);
}

/**
 * Poll the gateway for connectivity to inform the user
 * when the update is done.
 */
function pollUpdateReady() {
    $.ajax({
        url: 'api/' + apikey + '/config',
        type: 'GET',
        cache: false,
        headers: { 'Accept': apiversion },
        success: function(json, textStatus, jqXHR) {
            showAlert('alert-success', '<b>OK!</b> Software update done.');
            updateTimerId = undefined;
            getFullConfiguration();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            switch (jqXHR.status) {
            case 403:
                window.location.assign("/login.html");
                break;

            default:
                updateDots += ' .';
                showAlert('alert-info', '<b>Updating!</b> Please wait and don\'t close this page the update may take up several minutes.' + updateDots);
                updateTimerId = setTimeout(pollUpdateReady, 5000);
                break;
            }
        }
    });
}

/**
 * Send request to update the software via the selected update channel.
 */
function updateSoftware() {
    if (updateTimerId) {
        clearTimeout(updateTimerId);
        updateTimerId = undefined;
    }

    updateDots = "";

    $.ajax({
        url: 'api/' + apikey + '/config/update',
        type: 'POST',
        cache: false,
        headers: { 'Accept': apiversion },
        success: function(json) {
            showAlert('alert-info', '<b>Updating!</b> Please wait and don\'t close this page the update may take up several minutes.');
            updateTimerId = setTimeout(pollUpdateReady, 8000);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            showAlert('alert-error', '<b>Error!</b> Software update failed, please try again later.');
        }
    });
}

/**
 * Send request to update the firmware.
 */
function updateFirmware() {
    if (updateTimerId) {
        clearTimeout(updateTimerId);
        updateTimerId = undefined;
    }

    updateDots = "";

    $.ajax({
        url: 'api/' + apikey + '/config/updatefirmware',
        type: 'POST',
        cache: false,
        headers: { 'Accept': apiversion },
        success: function(json) {
            showAlert('alert-info', '<b>Updating!</b> Please wait and don\'t close this page the update may take up several minutes.');
            updateTimerId = setTimeout(pollUpdateReady, 8000);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            showAlert('alert-error', '<b>Error!</b> Firmware update failed, please try again later.');
        }
    });
}

function getFullConfiguration() {

    $.ajax({
        url: 'api/' + apikey,
        dataType: 'json',
        type: 'GET',
        cache: false,
        contentType: 'application/json; charset=utf-8',
        headers: { 'Accept': apiversion },
        success: function(json) {
            clearAlert();
            displaySetting(json);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            switch (jqXHR.status) {
            case 403:
                window.location.assign("/login.html");
                break;

            default:
                setTimeout(getFullConfiguration, 1000);
                showAlert('alert-error', '<b>Error!</b> Lost connection, retry in one second ...');
                break;
            }
        },
        timeout: 3000
    });

}

function unlockGateway(seconds) {

    var params = { "unlock" : seconds };

    clearAlert();

    $.ajax({
        url: 'api/' + apikey + '/config',
        dataType: 'json',
        type: 'PUT',
        cache: false,
        contentType: 'application/json; charset=utf-8',
        headers: { 'Accept': apiversion },
        data: JSON.stringify(params),
        success: function(json) {
            showAlert('alert-success', '<b>OK!</b> Unlocked gateway for ' + seconds + ' seconds.');
        },
        error: function(jqXHR, textStatus, errorThrown) {
            showAlert('alert-error', '<b>Error!</b> Unlock gateway failed!');
        }
    });
}

function showChangePasswordAlert(alert, text) {
    var txt = "";

    txt += '<div class="alert ' + alert + '">';
    txt += text;
    txt += '</div>';

    $('#changePasswordAlert').html(txt);
}

$('#changePasswordModal').on('show', function () {
    // clear alert
    $('#oldPasswordInput').val(""); 
    $('#newPasswordInput').val(""); 
    $('#confirmPasswordInput').val(""); 
    $('#changePasswordAlert').html(""); 
})

// check if user did specify a name
function sendChangePassword() {
    clearAlert();
    var oldpw = $('#oldPasswordInput').val();
    var newpw = $('#newPasswordInput').val();
    var confpw = $('#confirmPasswordInput').val();

    if (oldpw.length === 0) {
        showChangePasswordAlert('alert-error', 'Old password not specified!')
    }
    else if (newpw.length < 5) {
        showChangePasswordAlert('alert-error', 'New password must have at least 5 characters!')
    }
    else if (newpw.length === 0) {
        showChangePasswordAlert('alert-error', 'New password not specified!')
    }
    else if (newpw !== confpw) {
        showChangePasswordAlert('alert-error', 'New and confirm password differ!')
    }
    else {
        $('#changePasswordModal').modal('hide');

        var username = "delight"; // fixed
        // combine and base64 encode username:password as in HTTP basic authentification
        var oldhash = Base64.encode(username + ':' + oldpw);
        var newhash = Base64.encode(username + ':' + newpw);

        var params = {
            "username": username,
            "oldhash": oldhash,
            "newhash": newhash
        };

        $.ajax({
            url: 'api/' + apikey + '/config/password',
            dataType: 'json',
            type: 'PUT',
            contentType: 'application/json; charset=utf-8',
            headers: { 'Accept': apiversion },
            //processData: false,
            data: JSON.stringify(params),
            success: function(json) {
                showAlert('alert-success', '<b>OK!</b> Changed password.');
            },
            error: function(jqXHR, textStatus, errorThrown) {
                if (jqXHR.status === 401) {
                    showAlert('alert-error', '<b>Error!</b> Changing password failed, old password wrong!');
                }
                else {
                   showAlert('alert-error', '<b>Error!</b> Changing password failed!');
                }
            }
        });
    }
}

function sendConfig() {
    var params = { };

    clearAlert();

    params.name = $('#gwNameInput').val();
    params.groupdelay = $('#gwGroupDelayInput').val();
    params.discovery = false;

    if (params.name.length === 0) {
      showAlert('alert-error', '<b>Abort!</b> Gateway name not specified.');
      return;
    }

    if ($('#internetServiceCheckbox').prop('checked')) {
        params.discovery = true;
    }

    $.ajax({
        url: 'api/' + apikey + '/config',
        dataType: 'json',
        type: 'PUT',
        cache: false,
        contentType: 'application/json; charset=utf-8',
        headers: { 'Accept': apiversion },
        //processData: false,
        data: JSON.stringify(params),
        success: function(json) {
            showAlert('alert-success', '<b>OK!</b> Updated settings.');
        },
        error: function(jqXHR, textStatus, errorThrown) {
            showAlert('alert-error', '<b>Error!</b> Updating settings failed!');
        }
    });
}

$(document).ready(function() {
    // hidden handler to go to expert settings
    $('.page-header h1').on('click', function(e) {
        if (e.altKey) {
            window.location.assign("edit_config.html");
        }
    });

    //$('#sys-tabs').removeClass('tabs-left');
    getFullConfiguration();
});
