#ifndef DECONZ_APS_CONTROLLER_H
#define DECONZ_APS_CONTROLLER_H

/*
 * \author    dresden elektronik ingenieurtechnik gmbh: http://www.dresden-elektronik.de
 * \author    Support email: wireless@dresden-elektronik.de
 *
 * Copyright (c) 2013, dresden elektronik ingenieurtechnik gmbh. All rights reserved.
 *
 * Licensed under dresden elektronik's Limited License Agreement --> deEULA.txt
 */

#include <QObject>
#include <deconz/types.h>
#include <deconz/aps.h>

namespace deCONZ
{

/*! Parameters of type uint8_t.
 */
enum U8Parameter
{
    ParamCurrentChannel, //!< the current operation channel
    ParamDeviceType,     //!< deCONZ::Coordinator or deCONZ::Router
    ParamSecurityMode    //!< one of the deCONZ::SecurityMode values
};

/*! Parameters of type uint16_t.
 */
enum U16Parameter
{
    ParamPANID,    //!< the short PANID
    ParamNwkAddress //!< the network address of the device
};

/*! Parameters of type uint32_t.
 */
enum U32Parameter
{
    ParamChannelMask,      //!< the 32-bit bitmap with enabled channels set as bit
    ParamFirmwareVersion   //!< the firmware version of the connected device
};

/*! Parameters of type uint64_t.
 */
enum U64Parameter
{
    ParamApsUseExtendedPANID, //!< the extended PANID to use during join
    ParamExtendedPANID,       //!< the current extended PANID
    ParamMacAddress,          //!< the MAC address of the device
    ParamTrustCenterAddress   //!< the MAC address of the trust center
};

/*! Parameters of type QString.
 */
enum StringParameter
{
    ParamEmptyString //!< dummy
};

/*! Parameters of type QByteArray.
 */
enum ArrayParameter
{
    ParamNetworkKey,          //!< the 128-bit network key
    ParamTrustCenterLinkKey   //!< the 128-bit trust center link key
};

class Node;
class NodeEvent;

/*!
    \ingroup aps
    \class ApsController
    \brief Provides APSDE-DATA service and access to node cache.
 */
class DECONZ_DLLSPEC ApsController: public QObject
{
    Q_OBJECT

public:
    /*! Constructor. */
    ApsController(QObject *parent);
    /*! Deconstructor. */
    virtual ~ApsController();
    /*! Get the singleton instance of the ApsController. */
    static ApsController *instance();
    /*! Returns the current network state. */
    virtual State networkState() = 0;
    /*! Sets the current network state.

        \param state either NotInNetwork or InNetwork
        \retval Success the request is enqueued and will be processed
        \retval ErrorNotConnected if not connected to device
     */
    virtual int setNetworkState(State state) = 0;
    /*! Sets the permit join duration.

        \param duration 0..255 (in seconds)
        \retval Success the request is enqueued and will be processed
        \retval ErrorNotConnected if not connected to a network
     */
    virtual int setPermitJoin(uint8_t duration) = 0;
    /*!
        Send a APSDE-DATA.request to the network.

        Multible requests could be send in parallel.
        It is guaranteed that for each request a apsdeDataConfirm() signal is emitted
        after the request is processed.

        The confirmation might take from 5 milliseconds up to serval seconds depending on
        if a new route must be found or the destination is not available.

        To match the request to the confirmation compare their ids,
              ApsDataRequest::id() == ApsDataConfirm::id().

        \retval Success the request is enqueued and will be processed
        \retval ErrorNotConnected if not connected to a network
        \retval ErrorQueueIsFull request queue is full
        \retval ErrorNodeIsZombie destionation node is zombie node, only ZDP requests are allowed
     */
    virtual int apsdeDataRequest(const ApsDataRequest &req) = 0;
    /*! Fills in missing network or extended IEEE address information.
     *  \param addr at least nwk() or ext() must be set
     *  \retval Success on success
     *  \retval ErrorNotFound if the missing address part was not available
     */
    virtual int resolveAddress(Address &addr) = 0;
    /*! Iterates through the internal node cache.
        \code {cpp}
        int i = 0;
        const deCONZ::Node *node;
        deCONZ::ApsController *ctrl = deCONZ::ApsController::instance();

        while (ctrl->getNode(i, &node) == 0)
        {
          // do something with *node
          i++;
        }
        \endcode

        The node with the index 0 is always the own node.

        \param index a index >= 0
        \param node a pointer to a user provides deCONZ::Node pointer
        \retval 0 if \p node points to a valid deCONZ::Node
        \retval -1 if no node is available for \p index
     */
    virtual int getNode(int index, const Node **node) = 0;
    /*! TODO: return object instead of pointer ... */
    //virtual const Node &getNode(int index) = 0;
    /*! Updates the data of a node in the internal node cache.
        \param node a node which must have a extended IEEE address
     */
    virtual bool updateNode(const Node &node) = 0;
    /*! Returns a 8-bit parameter.
        \param parameter - the parameter identifier
        \return the parameter value
     */
    virtual uint8_t getParameter(U8Parameter parameter) = 0;
    /*! Returns a 16-bit parameter.
        \param parameter - the parameter identifier
        \return the parameter value
     */
    virtual uint16_t getParameter(U16Parameter parameter) = 0;
    /*! Returns a 32-bit parameter.
        \param parameter - the parameter identifier
        \return the parameter value
     */
    virtual uint32_t getParameter(U32Parameter parameter) = 0;
    /*! Returns a 64-bit parameter.
        \param parameter - the parameter identifier
        \return the parameter value
     */
    virtual uint64_t getParameter(U64Parameter parameter) = 0;
    /*! Returns a string parameter.
        \param parameter - the parameter identifier
        \return the parameter value
     */
    virtual QString getParameter(StringParameter parameter) = 0;
    /*! Returns a byte array parameter.
        \param parameter - the parameter identifier
        \return the parameter value
     */
    virtual QByteArray getParameter(ArrayParameter parameter) = 0;

Q_SIGNALS:
    /*! Is emitted on the reception of a APSDE-DATA.confirm primitive.

        \note The id of the confirmation equals the id from the former request.
        \sa  apsdeDataRequest()
     */
    void apsdeDataConfirm(const ApsDataConfirm &);

    /*! Is emitted on the reception of a APSDE-DATA.indication primitive.

        A indication might be received at any time and is not necessarily
        releated to a former request.

        No filtering is done by the application any indication which is
        received will be forwarded.
     */
    void apsdeDataIndication(const ApsDataIndication &);

    /*! Is emitted on changes in the nodecache or user interactions. */
    void nodeEvent(const deCONZ::NodeEvent&);
};

} // namespace deCONZ

#endif // DECONZ_APS_CONTROLLER_H
