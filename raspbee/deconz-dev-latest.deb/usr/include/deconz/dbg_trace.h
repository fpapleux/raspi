#ifndef DECONZ_DBG_TRACE_H
#define DECONZ_DBG_TRACE_H

/*
 * \author    dresden elektronik ingenieurtechnik gmbh: http://www.dresden-elektronik.de
 * \author    Support email: wireless@dresden-elektronik.de
 *
 * Copyright (c) 2013, dresden elektronik ingenieurtechnik gmbh. All rights reserved.
 *
 * Licensed under dresden elektronik's Limited License Agreement --> deEULA.txt
 */

#include <deconz/types.h>

#define DBG_INFO     0x00000001
#define DBG_ERROR    0x00000002
#define DBG_PROT     0x00000004
#define DBG_AIR      0x00000008
#define DBG_WIRE     0x00000010
#define DBG_PROTBUF  0x00000020
#define DBG_ZDP      0x00000040
#define DBG_ZCL      0x00000080
#define DBG_APS      0x00000100
#define DBG_PROT_L2  0x00000200
#define DBG_ZCLDB    0x00000400
#define DBG_INFO_L2  0x00000800
#define DBG_HTTP     0x00001000
#define DBG_TLINK    0x00002000
#define DBG_ERROR_L2 0x00004000

#define DBG_Assert(e) ((e) ? true : (DBG_Printf(DBG_ERROR, "%s,%d: assertion '%s' failed\n", Q_FUNC_INFO, __LINE__, #e), false))

#ifdef __cplusplus
extern "C" {
#endif

void DECONZ_DLLSPEC DBG_Init(FILE *logfile);
void DECONZ_DLLSPEC DBG_WriteString(int level, const char *str);
int DECONZ_DLLSPEC DBG_Printf(int level, const char *format, ...);
void DECONZ_DLLSPEC DBG_Enable(int item);
int DECONZ_DLLSPEC DBG_IsEnabled(int item);
uint8_t * DECONZ_DLLSPEC DBG_HexToAscii(uint8_t *hex, uint8_t length, uint8_t *ascii);

#ifdef __cplusplus
}
#endif

#endif // DECONZ_DBG_TRACE_H
