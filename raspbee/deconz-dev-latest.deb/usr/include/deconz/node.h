#ifndef DECONZ_NODE_H
#define DECONZ_NODE_H

/*
 * \author    dresden elektronik ingenieurtechnik gmbh: http://www.dresden-elektronik.de
 * \author    Support email: wireless@dresden-elektronik.de
 *
 * Copyright (c) 2013, dresden elektronik ingenieurtechnik gmbh. All rights reserved.
 *
 * Licensed under dresden elektronik's Limited License Agreement --> deEULA.txt
 */

#include <deconz/types.h>
#include <deconz/aps.h>
#include <deconz/zdp_descriptors.h>

namespace deCONZ
{

class NodePrivate;

/*!
    \ingroup aps
    \class Node
    \brief Represents a ZigBee node with all its descriptors and clusters.
 */
class DECONZ_DLLSPEC Node
{
public:
    /*! Constructor. */
    Node();
    /*! Copy constructor. */
    Node(const Node &other);
    /*! Assignment operator. */
    Node& operator=(const Node &other);
    /*! Deconstructor. */
    virtual ~Node();
    /*! Returns the current node state. */
    virtual CommonState state() const = 0;
    /*! Returns the modifyable node address. */
    deCONZ::Address &address();
    /*! Returns the const node address. */
    const deCONZ::Address &address() const;
    /*! Returns true if the node is a coordinator. */
    bool isCoordinator() const;
    /*! Returns true if the node is a router. */
    bool isRouter() const;
    /*! Returns true if the node is a end-device. */
    bool isEndDevice() const;
    /*! Returns true if the node not reachable. */
    bool isZombie() const;
    /*! Sets the reachable state of the node. */
    void setIsZombie(bool isZombie);
    /*! Returns the user descriptor (usually the nodes name). */
    const QString &userDescriptor() const;
    /*! Sets the user descriptor.
        \param userDescriptor a string with a max length of 16
     */
    void setUserDescriptor(const QString &userDescriptor);
    /*! Returns the device type as string which might be Coordinator, Router or End device. */
    QString deviceTypeString();
    /*! Returns all known active endpoint numbers. */
    const std::vector<uint8_t> &endpoints() const;
    /*! Sets the active endpoint numbers. */
    void setActiveEndpoints(const std::vector<uint8_t> &ep);
    /*! Returns a simple descriptor for a \p endpoint.
        \param endpoint shall be between 1-254
        \returns a pointer to the internal SimpleDescriptor if found
        \retval 0 if no simple descriptor is available for \p endpoint
     */
    SimpleDescriptor *getSimpleDescriptor(uint8_t endpoint);
    /*! Adds or updates a simple descriptor.
        \param descr a simple descriptor with endpoint between 1-254
     */
    void setSimpleDescriptor(const SimpleDescriptor &descr);
    /*! Returns the modifyable list of a simple descriptors. */
    QList<SimpleDescriptor> &simpleDescriptors();
    /*! Returns the const list of a simple descriptors. */
    const QList<SimpleDescriptor> &simpleDescriptors() const;
    /*! Copy the simple descriptor specified by \p endpoint from internal storage to \p descr.
        \param endpoint shall be between 1-254
        \param descr pointer to a user simple descriptor
        \retval 0 on success
        \retval -1 if not found
        \retval -1 descr is 0
     */
    int copySimpleDescriptor(uint8_t endpoint, SimpleDescriptor *descr) const;
    /*! Returns the node descriptor. */
    const NodeDescriptor & nodeDescriptor() const;
    /*! Sets the node descriptor.
        \param descr a node descriptor
     */
    void setNodeDescriptor(const NodeDescriptor &descr);
    /*! Returns the power descriptor. */
    const PowerDescriptor &powerDescriptor() const;
    /*! Sets the power descriptor.
        \param descr a power descriptor
     */
    void setPowerDescriptor(const PowerDescriptor &descr);
    /*! Returns the mac capabilities. */
    const MacCapabilities &macCapabilities() const;
    /*! Sets the mac capabilities.
        \param cap or combined value of deCONZ::MacCapability
     */
    void setMacCapabilities(MacCapabilities cap);
    /*! Updates some fields based on the mac capabilities. */
    void updateMacCapabilities();
    /*! Resets internal fields and state. */
    void resetAll();

protected:
    NodePrivate *d_ptr;
    Q_DECLARE_PRIVATE(Node)
};

}

#endif // DECONZ_NODE_H
