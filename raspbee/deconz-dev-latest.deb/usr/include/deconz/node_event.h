#ifndef DECONZ_NODE_EVENT_H
#define DECONZ_NODE_EVENT_H

/*
 * \author    dresden elektronik ingenieurtechnik gmbh: http://www.dresden-elektronik.de
 * \author    Support email: wireless@dresden-elektronik.de
 *
 * Copyright (c) 2013, dresden elektronik ingenieurtechnik gmbh. All rights reserved.
 *
 * Licensed under dresden elektronik's Limited License Agreement --> deEULA.txt
 */

#include <QObject>
#include <deconz/types.h>
#include <deconz/aps.h>

namespace deCONZ {

// forward declarations
class Node;
class NodeEventPrivate;

/*!
    \ingroup aps
    \class NodeEvent
    \brief Node events are triggered from the ApsController::nodeEvent() signal to notify about changes in the node cache.
 */
class DECONZ_DLLSPEC NodeEvent
{
public:
    /*! Events which might occur for a node. */
    enum Event
    {
        /*! The user seleced a node in the GUI. */
        NodeSelected,
        /*! A node in the GUI gots deselected. */
        NodeDeselected,
        /*! A new node was added to the nodecache. */
        NodeAdded,
        /*! A node was removed from nodecache. */
        NodeRemoved,
        /*! A node reachable state changed.
            \see isZombie()
         */
        NodeZombieChanged,
        /*! The node descriptor was updated. */
        UpdatedNodeDescriptor,
        /*! The power descriptor was updated. */
        UpdatedPowerDescriptor,
        /*! The user descriptor (node name) was updated. */
        UpdatedUserDescriptor,
        /*! The simple descriptor was updated.
            \see endpoint()
         */
        UpdatedSimpleDescriptor,
        /*! Data in a cluster was updated.
            \see endpoint(), profileId(), clusterId()
         */
        UpdatedClusterData
    };

    /*! Constructor. */
    NodeEvent();
    /*! Constructor used by controller. */
    NodeEvent(Event event, const Node *node = 0, uint8_t endpoint = 0, uint16_t profileId = 0, uint16_t clusterId = 0);
    /*! Constructor used by controller. */
    NodeEvent(Event event, const Node *node, const ApsDataIndication &ind);
    /*! Copy Constructor. */
    NodeEvent(const NodeEvent &other);
    /*! Copy assignment constructor. */
    NodeEvent &operator= (const NodeEvent &other);
    /*! Deconstructor. */
    ~NodeEvent();
    /*! Returns the node which belongs to the event. */
    const Node *node() const;
    /*! Returns the event type. */
    Event event() const;
    /*! Returns the endpoint related to the event.

        Endpoint is available in following events:
           - UpdatedSimpleDescriptor
           - UpdatedClusterData
     */
    uint8_t endpoint() const;
    /*! Returns the profile identifier related to the event.
        Profile identifier is available in following events:
           - UpdatedClusterData
     */
    uint16_t profileId() const;
    /*! Returns the cluster identifier related to the event.
        Cluster identifier is available in following events:
           - UpdatedClusterData
     */
    uint16_t clusterId() const;

private:
    NodeEventPrivate *d_ptr;
    Q_DECLARE_PRIVATE(NodeEvent)
};

} // namespace deCONZ

Q_DECLARE_METATYPE(deCONZ::NodeEvent)

#endif // DECONZ_NODE_EVENT_H
