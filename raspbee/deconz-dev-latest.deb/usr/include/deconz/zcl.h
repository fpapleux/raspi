#ifndef DECONZ_ZCL_H
#define DECONZ_ZCL_H

/*
 * \author    dresden elektronik ingenieurtechnik gmbh: http://www.dresden-elektronik.de
 * \author    Support email: wireless@dresden-elektronik.de
 *
 * Copyright (c) 2013, dresden elektronik ingenieurtechnik gmbh. All rights reserved.
 *
 * Licensed under dresden elektronik's Limited License Agreement --> deEULA.txt
 */

#include <QIcon>
#include <QList>
#include <QHash>
#include <QVariant>
#include <QStringList>
#include <QDebug>
#include <deconz/types.h>

//#define ZCL_LOAD_DBG
//#define ZCL_LOAD_DBG_COMMAND

#define ZCL_ENUM 0x00

/*!
    \defgroup zcl ZCL
    \brief ZigBee Cluster Library (ZCL).
*/

namespace deCONZ
{
class ApsDataIndication;
}

namespace deCONZ
{
    /*! Various data types as defined in ZigBee ZCL specification */
    enum ZclDataTypeId
    {
        ZclNoData    = 0x00,
        Zcl8BitData  = 0x08,
        Zcl16BitData = 0x09,
        Zcl24BitData = 0x0a,
        Zcl32BitData = 0x0b,
        Zcl40BitData = 0x0c,
        Zcl48BitData = 0x0d,
        Zcl56BitData = 0x0e,
        Zcl64BitData = 0x0f,
        ZclBoolean   = 0x10,
        Zcl8BitBitMap   = 0x18,
        Zcl16BitBitMap  = 0x19,
        Zcl24BitBitMap  = 0x1a,
        Zcl32BitBitMap  = 0x1b,
        Zcl40BitBitMap  = 0x1c,
        Zcl48BitBitMap  = 0x1d,
        Zcl56BitBitMap  = 0x1e,
        Zcl64BitBitMap  = 0x1f,
        Zcl8BitUint  = 0x20,
        Zcl16BitUint = 0x21,
        Zcl24BitUint = 0x22,
        Zcl32BitUint = 0x23,
        Zcl40BitUint = 0x24,
        Zcl48BitUint = 0x25,
        Zcl56BitUint = 0x26,
        Zcl64BitUint = 0x27,
        Zcl8BitInt  = 0x28,
        Zcl16BitInt = 0x29,
        Zcl24BitInt = 0x2a,
        Zcl32BitInt = 0x2b,
        Zcl40BitInt = 0x2c,
        Zcl48BitInt = 0x2d,
        Zcl56BitInt = 0x2e,
        Zcl64BitInt = 0x2f,
        Zcl8BitEnum  = 0x30,
        Zcl16BitEnum = 0x31,
        ZclOctedString = 0x41,
        ZclCharacterString     = 0x42,
        ZclLongOctedString     = 0x43,
        ZclLongCharacterString = 0x44,
        ZclTimeOfDay  = 0xe0,
        ZclDate       = 0xe1,
        ZclUtcTime    = 0xe2,
        ZclClusterId         = 0xe8,
        ZclAttributeId       = 0xe9,
        ZclBACNetOId         = 0xea,
        ZclIeeeAddress       = 0xf0,
        Zcl128BitSecurityKey = 0xf1

    };

    /*! General ZCL command ids every cluster shall support. */
    enum ZclGeneralCommandId
    {
        ZclReadAttributesId               = 0x00,
        ZclReadAttributesResponseId       = 0x01,
        ZclWriteAttributesId              = 0x02,
        ZclWriteAttributesUndividedId     = 0x03,
        ZclWriteAttributesResponseId      = 0x04,
        ZclWriteAttributesNoResponseId    = 0x05,
        ZclConfigureReportingId           = 0x06,
        ZclConfigureReportingResponseId   = 0x07,
        ZclReadReportingConfigId          = 0x08,
        ZclReadReportingConfigResponseId  = 0x09,
        ZclReportAttributesId             = 0x0a,
        ZclDefaultResponseId              = 0x0b,
        ZclDiscoverAttributesId           = 0x0c,
        ZclDiscoverAttributesResponseId   = 0x0d
    };

    /*!
        General ZCL Frame Format

        Bits
        ------ Header ----------------
        8         Frame control
        0/16      Manufacturer code
        8         Transaction sequence
        8         Command Id
        ------ ZCL payload -------------
        Variable  Frame payload
        ------------------------------
     */

    /*! Frame control flags used in ZCL frame header. */
    enum ZclFrameControl
    {
        ZclFCProfileCommand          = 0x00,
        ZclFCClusterCommand          = 0x01,
        ZclFCManufacturerSpecific    = 0x04,
        ZclFCDirectionServerToClient = 0x08,
        ZclFCDirectionClientToServer = 0x00,
        ZclFCEnableDefaultResponse   = 0x00,
        ZclFCDisableDefaultResponse  = 0x10
    };

    class ZclFramePrivate;

    /*!
        \ingroup zcl
        \class ZclFrame
        \brief Helper to build ZCL based payloads to be transported via ApsDataRequest.
     */
    class DECONZ_DLLSPEC ZclFrame
    {
    public:
        /*! Constructor. */
        ZclFrame();
        /*! Copy constructor. */
        ZclFrame(const ZclFrame &other);
        /*! Copy assignment constructor. */
        ZclFrame &operator=(const ZclFrame &other);
        /*! Deconstructor. */
        virtual ~ZclFrame();
        /*! Returns ZCL header frame control field. */
        uint8_t frameControl() const;
        /*! Sets the ZCL header frame control field.
            \param frameControl OR combinded value of deCONZ::ZclFrameControl flags
         */
        void setFrameControl(uint8_t frameControl);
        /*! Returns the vendor specific manufacturer code. */
        uint16_t manufacturerCode() const;
        /*! Sets the vendor specific manufacturer code. */
        void setManufacturerCode(uint16_t code);
        /*! Returns the sequence number associated with a request. */
        uint8_t sequenceNumber() const;
        /*! Sets the sequence number of a request. */
        void setSequenceNumber(uint8_t seqNumber);
        /*! Returns the ZCL command identifier. */
        uint8_t commandId() const;
        /*! Sets the ZCL command identifier. */
        void setCommandId(uint8_t commandId);
        /*! Returns the const ZCL payload. */
        const QByteArray &payload() const;
        /*! Returns the modifiable ZCL payload. */
        QByteArray &payload();
        /*! Sets the ZCL payload. */
        void setPayload(const QByteArray &payload);
        /*! Writes the ZCL frame in ZigBee standard conform format to the \p stream.
            \param stream shall write to a ApsDatarequest::asdu() buffer
         */
        void writeToStream(QDataStream &stream);
        /*! Reads a ZCL frame in ZigBee standard conform format from the \p stream.
            \param stream shall read from a ApsDatarequest::asdu() buffer
         */
        void readFromStream(QDataStream &stream);
        /*! Returns true if the command() is related to a cluster (for example OnOff cluster). */
        bool isClusterCommand() const;
        /*! Returns true if the command() is profile wide (any ZclGeneralCommandId). */
        bool isProfileWideCommand() const;
        /*! Returns true if the ZCL frame is a default response. */
        bool isDefaultResponse() const;
        /*! Returns the command identifier wich belongs to a default response. */
        uint8_t defaultResponseCommandId();
        /*! Returns the ZCL status wich belongs to a default response. */
        ZclStatus defaultResponseStatus();

    private:
        ZclFramePrivate *d_ptr;
        Q_DECLARE_PRIVATE(ZclFrame)
    };

    class ZclDataTypePrivate;

    /*!
        \ingroup zcl
        \class ZclDataType
        \brief Represents the data type of a ZigBee cluster attribute.
     */
    class DECONZ_DLLSPEC ZclDataType
    {
    public:
        /*! Constructor. */
        ZclDataType();
        /*! Constructor used by ZCLDB parser. */
        ZclDataType(uint8_t id, const QString &name, const QString &shortname, int length, char analogDiscrete);
        /*! Returns the data type identifier. */
        uint8_t id() const;
        /*! Returns the data type name. */
        const QString &name() const;
        /*! Returns the data type short name (bmp8, uint8, enum16, ...). */
        const QString &shortname() const;
        /*! Returns the length of this data type in bytes (uint8 -> 1, uint32 = 4, ...). */
        int length() const;
        /*! Returns true if this data type object has valid data. */
        bool isValid() const;
        /*! Returns true if this data type represents analog data. */
        bool isAnalog() const;
        /*! Returns true if this data type represents discrete data. */
        bool isDiscrete() const;

    private:
        ZclDataTypePrivate *d_ptr;
        Q_DECLARE_PRIVATE(ZclDataType)
    };

    /*! Allowed access method of a ZclAttribute. */
    enum ZclAccess
    {
        ZclRead = 0x1,
        ZclWrite = 0x2,
        ZclReadWrite = 0x3
    };

    class ZclAttributePrivate;

    /*!
        \ingroup zcl
        \class ZclAttribute
        \brief Represents a ZigBee cluster attribute.
     */
    class DECONZ_DLLSPEC ZclAttribute
    {
    public:
        /*! Used to change the display format in the GUI. */
        enum FormatHint
        {
            DefaultFormat = 0, //!< Use the default format for a value
            Prefix, //!< Prepend prefix like 0x or 0b
            SliderFormat //!< Present a numeric value as a slider.
        };
        /*! Constructor */
        ZclAttribute();
        /*! Constructor used by ZCLDB parser. */
        ZclAttribute(uint16_t id, uint8_t type, const QString &name, ZclAccess access, bool required);
        /*! Copy constructor */
        ZclAttribute(const ZclAttribute &other);
        /*! Copy assignment onstructor */
        ZclAttribute &operator= (const ZclAttribute &other);
        /*! Deconstructor */
        ~ZclAttribute();
        /*! Returns the attribute identifier. */
        uint16_t id() const;
        /*! Returns the attribute description. */
        const QString &description() const;
        /*! Sets the attribute description. */
        void setDescription(const QString &description);
        /*! Returns the attribute data type which is a ZclDataTypeId value. */
        uint8_t dataType() const;
        /*! Sets the attribute data type which is a ZclDataTypeId value. */
        void setDataType(uint8_t type);
        /*! Returns the attribute name. */
        const QString &name() const;
        /*! Returns the attribute numberic value. */
        const NumericUnion &numericValue() const;
        /*! Sets the attribute numberic value. */
        void setNumericValue(const NumericUnion &value);

        /*! Returns the name of a enumerator or bitmap bit.

            There:
                    0 < bitOrEnum < bitCount()
                    or bitOrEnum is a known enumerator

            If bitOrEnum is unknown QString() will be returned.
         */
        QString valueNameAt(int bitOrEnum) const;
        /*! Returns all enumerator or bitmap bit names. */
        QStringList valuesNames() const;
        /*! Returns a list of all known bits or enumerators. */
        const std::vector<int> &valueNamePositions() const;
        /*! Sets the attribute bool value. */
        void setValue(bool value);
        /*! Sets the attribute unsigned value (8..64-bit). */
        void setValue(quint64 value);
        /*! Sets the attribute signed value (8..64-bit). */
        void setValue(qint64 value);
        /*! Sets the attribute value (various formats). */
        void setValue(const QVariant &value);
        /*! Sets the \p time where the attribute was last read. */
        void setLastRead(time_t time);
        uint16_t listSizeAttribute() const;
        void setListSizeAttribute(uint16_t id);
        bool isList() const;
        int listSize() const;
        void setListSize(int listSize);
        /*! Returns the last read time. */
        time_t lastRead() const;
        /*! Returns true if the attribute is read only. */
        bool isReadonly() const;
        /*! Returns true if the attribute is mandatory. */
        bool isMandatory() const;
        /*! Returns true if the attribute is available on the device. */
        bool isAvailable() const;
        /*! Sets the is available flag of the attribute. */
        void setAvailable(bool available);
        /*! Returns the numeric base (for GUI display). */
        uint8_t numericBase() const;
        /*! Sets the numeric \p base (for GUI display). */
        void setNumericBase(uint8_t base);
        /*! Returns the current enumerator. */
        uint enumerator() const;
        /*! Sets the current enumerator. */
        void setEnumerator(uint value);
        /*! Set/unset a bit in the bitmap. */
        void setBit(uint bit, bool one);
        /*! Returns true if a bit is set where 0 < bit < bitCount() */
        bool bit(int bit) const;
        /*! Returns the number of bits in the bitmap. */
        int bitCount() const;
        /*! Returns the bitmap (8..64-bit) */
        quint64 bitmap() const;
        /*! Sets the bitmap to \p bmp (8..64-bit) */
        void setBitmap(quint64 bmp);
        /*! Returns the number of enum values. */
        int enumCount() const;
        /*! Returns the id of the enumeration. */
        quint8 enumerationId() const;
        /*! Sets the enumeration id. */
        void setEnumerationId(quint8 id);
        /*! Writes the attribute to \p stream. */
        bool writeToStream(QDataStream &stream) const;
        /*! Reads the attribute from \p stream. */
        bool readFromStream(QDataStream &stream);
        /*! Returns the attribute as string representation. */
        QString toString(FormatHint formatHint = DefaultFormat) const;
        /*! Returns the attribute as string representation for given data type. */
        QString toString(const deCONZ::ZclDataType &dataType, FormatHint formatHint = DefaultFormat) const;
        /*! Returns the minimum report interval. */
        uint16_t minReportInterval() const;
        /*! Sets the minimum report \p interval. */
        void setMinReportInterval(uint16_t interval);
        /*! Returns the maximum report interval. */
        uint16_t maxReportInterval() const;
        /*! Sets the maximum report \p interval. */
        void setMaxReportInterval(uint16_t interval);
        /*! Returns the report timeout period. */
        uint16_t reportTimeoutPeriod() const;
        /*! Sets the report timeout \p period. */
        void setReportTimeoutPeriod(uint16_t period);
        /*! Returns the reportable change as numeric value. */
        const NumericUnion &reportableChange() const;
        /*! Sets the reportable change. */
        void setReportableChange(const NumericUnion &reportableChange);
        /*! Writes the reportable change to \p stream TODO: describe. */
        bool writeReportableChangeToStream(QDataStream &stream) const;
        /*! Reads the reportable change from \p stream TODO: describe. */
        bool readReportableChangeFromStream(QDataStream &stream);
        /*! Sets the format hint for GUI display. */
        void setFormatHint(FormatHint formatHint);
        /*! Returns the format hint for GUI display. */
        FormatHint formatHint() const;
        /*! Return the minimum range. */
        int rangeMin() const;
        /*! Sets the minimum range. */
        void setRangeMin(int rangeMin);
        /*! Return the maximum range. */
        int rangeMax() const;
        /*! Sets the maximum range. */
        void setRangeMax(int rangeMax);

    private:
        friend class ZclDataBase;
        ZclAttributePrivate *d_ptr;
        Q_DECLARE_PRIVATE(ZclAttribute)
    };

    class ZclAttributeSetPrivate;

    /*!
        \ingroup zcl
        \class ZclAttributeSet
        \brief Represents a named group of ZclAttribute.
     */
    class DECONZ_DLLSPEC ZclAttributeSet
    {
    public:
        /*! Constructor. */
        ZclAttributeSet();
        /*! Copy constructor. */
        ZclAttributeSet(const ZclAttributeSet &other);
        /*! Copy assignment constructor. */
        ZclAttributeSet &operator= (const ZclAttributeSet &other);
        /*! Constructor used by ZCLDB. */
        ZclAttributeSet(uint16_t id, const QString &description);
        /*! Returns the attribute set identifier. */
        uint16_t id() const;
        /*! Returns the attribute set description. */
        const QString &description() const;
        /*! Returns a list of indexes into ZclCluster::attributes() list. */
        const std::vector<int> &attributes() const;
        /*! Adds a attribute to the set.
            \param idx index into ZclCluster::attributes() list
         */
        void addAttribute(int idx);

    private:
        ZclAttributeSetPrivate *d_ptr;
        Q_DECLARE_PRIVATE(ZclAttributeSet)
    };

    /*! ZCL cluster side where client is a out cluster and server is a in cluster. */
    enum ZclClusterSide
    {
        ClientCluster = 0,
        ServerCluster = 1
    };

    class ZclCommandPrivate;

    /*!
        \ingroup zcl
        \class ZclCommand
        \brief Represents a ZigBee cluster command (ZCL and non-ZCL).
     */
    class DECONZ_DLLSPEC ZclCommand
    {
    public:
        /*! Constructor */
        ZclCommand();
        /*! Copy constructor */
        ZclCommand(const ZclCommand &other);
        /*! Copy assignment constructor */
        ZclCommand&operator =(const ZclCommand &other);
        /*! Constructor used by ZCLDB parser. */
        ZclCommand(uint8_t id, const QString &name, bool required, bool recv, const QString &description = QString());
        /*! Deconstructor */
        ~ZclCommand();
        /*! Returns the command identifier. */
        uint8_t id() const;
        /*! Sets the command identifier. */
        void setId(uint8_t id);
        /*! Returns true if this command has valid data. */
        bool isValid() const;
        /*! Returns the response command identifier. */
        uint8_t responseId() const;
        /*! Sets the response command identifier. */
        void setResponseId(uint8_t id);
        /*! Returns true if this command expects a response. */
        bool hasResponse() const;
        /*! Returns true if the command will be received. */
        bool directionReceived() const;
        /*! Returns false if the command will be send. */
        bool directionSend() const;
        /*! Returns the name of the command. */
        const QString &name() const;
        /*! Returns the description of the command. */
        const QString &description() const;
        /*! Sets the description of the command. */
        void setDescription(const QString &description);
        /*! Returns true if the command is profile wide (not cluster specific). */
        bool isProfileWide() const;
        /*! Sets the is profile wide flag. */
        void setIsProfileWide(bool profileWide);
        /*! Returns true if the disable default response flag is set. */
        bool disableDefaultResponse() const;
        /*! Sets the disable default response flag. */
        void setDisableDefaultResponse(bool disable);
        /*! Returns the const list of command parameters. */
        const std::vector<ZclAttribute> &parameters() const;
        /*! Returns the modifiable list of command parameters. */
        std::vector<ZclAttribute> &parameters();
        /*! Reads the command parameters from \p stream. */
        bool readFromStream(QDataStream &stream);
        /*! Writes the command parameters to \p stream. */
        bool writeToStream(QDataStream &stream) const;

    private:
        ZclCommandPrivate *d_ptr;
        Q_DECLARE_PRIVATE(ZclCommand)
    };

    class ZclClusterPrivate;

    /*!
        \ingroup zcl
        \class ZclCluster
        \brief Represents a ZigBee cluster (ZCL and non-ZCL).
        \see SimpleDescriptor::inClusters(), SimpleDescriptor::outClusters()
     */
    class DECONZ_DLLSPEC ZclCluster
    {
    public:
        /*! Constructor. */
        ZclCluster();
        /*! Copy constructor. */
        ZclCluster(const ZclCluster &other);
        /*! Constructor used by ZCLDB parser. */
        ZclCluster(uint16_t id, const QString &name, const QString &description = QString());
        /*! Copy assignment constructor. */
        ZclCluster &operator=(const ZclCluster &other);
        /*! Deconstructor. */
        ~ZclCluster();
        /*! Returns the cluster identifier. */
        uint16_t id() const;
        /*! Sets the cluster identifier. */
        void setId(uint16_t id);
        /*! Returns the opposite cluster identifier (server/client) which is the same for ZCL based clusters. */
        uint16_t oppositeId() const;
        /*! Sets the opposite cluster identifier. */
        void setOppositeId(uint16_t id);
        /*! Returns the cluster name. */
        const QString &name() const;
        /*! Returns the cluster description. */
        const QString &description() const;
        /*! Sets the cluster description. */
        void setDescription(const QString &description);
        /*! Returns true if this cluster has valid data. */
        bool isValid() const;
        /*! Returns true if this cluster is ZCL based. */
        bool isZcl() const;
        /*! Sets the cluster is ZCL based flag. */
        void setIsZcl(bool isZcl);
        /*! Returns true if this is a server (in) cluster. */
        bool isServer() const;
        /*! Returns true if this is a client (out) cluster. */
        bool isClient() const;
        /*! Sets the is a server (in) cluster flag, this also effects the isClient() method. */
        void setIsServer(bool isServer);
        /*! Returns the modifiable attributes list. */
        std::vector<ZclAttribute> &attributes();
        /*! Returns the modifiable attributes list. */
        const std::vector<ZclAttribute> &attributes() const;
        /*! Returns the const attribute sets list. */
        std::vector<ZclAttributeSet> &attributeSets();
        /*! Returns the const attribute sets list. */
        const std::vector<ZclAttributeSet> &attributeSets() const;
        /*! Reads a ZCL based command from a ZCL frame. */
        bool readCommand(const ZclFrame &zclFrame);
        /*! Reads a non-ZCL based single command (like ZDP) from APSDE-DATA.indication. */
        bool readCommand(const ApsDataIndication &ind);
        /*! Returns the modifiable list of commands. */
        std::vector<ZclCommand> &commands();
        /*! Returns the const list of commands. */
        const std::vector<ZclCommand> &commands() const;

    private:
        ZclClusterPrivate *d_ptr;
        Q_DECLARE_PRIVATE(ZclCluster)
    };
} // namespace deCONZ

#endif // DECONZ_ZCL_H
